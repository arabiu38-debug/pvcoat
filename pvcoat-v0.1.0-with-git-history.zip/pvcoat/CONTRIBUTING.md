# Contributing

Contributions are welcome, especially in the two areas where this package is
weakest.

## Most valuable contributions

1. **Experimental validation data.** Predicted versus measured thickness, or an
   observed operating-window boundary, for any ink and any head. Include the ink
   properties, the geometry, the measurement method and the uncertainty. Even a
   disagreement is valuable; especially a disagreement.
2. **Corrections to the implemented physics.** If an equation here is wrong, or
   a coefficient or a validity range is misquoted, open an issue citing the
   primary source and the specific expression. This is the most useful issue you
   can file.

## Ground rules for new models

Every model added must arrive with:

- the published source, cited with a DOI, added to `pvcoat/references.py` and
  pointed to by the function's `.references` attribute;
- the equation written out in the docstring and in `docs/MODELS.md`, with its
  symbols and units;
- the validity range it was derived for, and a check in `pvcoat.validity` that
  flags results computed outside it;
- tests that check a closed form, a limiting case or an analytic identity, not a
  recorded output. A test that only pins today's number protects nothing.

No fitted or tuned coefficients. If a coefficient is empirical, it belongs in a
module constant so a user can replace it with their own measurement.

## Development

```bash
git clone <this repository>
cd pvcoat
pip install -e ".[dev]"
pytest
```

The package has no runtime dependencies and should keep none. matplotlib is used
only by the example scripts and lives in the `viz` extra.

Style: keep functions small and named after the quantity they compute; SI
in and SI out; document the unit of every argument.

## Conduct

Be straightforward and courteous. Critique the physics, not the person.
