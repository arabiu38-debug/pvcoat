---
title: "pvcoat: operability windows and film thickness for slot-die and blade coating"
tags:
  - Python
  - coating
  - thin films
  - slot-die coating
  - blade coating
  - perovskite photovoltaics
  - roll-to-roll manufacturing
authors:
  - name: Abdulai Rabiu
    orcid: 0000-0002-3739-140X
    affiliation: 1
    corresponding: true
affiliations:
  - name: Wright Center for Photovoltaics Innovation and Commercialization, Department of Physics and Astronomy, University of Toledo, Toledo, Ohio, USA
    index: 1
bibliography: paper.bib
---

> **NOT FOR SUBMISSION IN THIS FORM.** This draft is held until pvcoat has
> independent users and the experimental validation described in
> `docs/NEXT_STEPS.md` exists. JOSS asks for substantial scholarly effort and a
> tool with a demonstrated user community; a v0.1 with neither would not survive
> review and would waste reviewers' time. See `docs/PUBLISH_GUIDE.md`.

# Summary

Slot-die and blade coating deposit the functional layers of printed
optoelectronic devices, and both fail outside a bounded region of process
parameters. The boundaries of that region have been derived and measured since
the 1940s, but the results are scattered across coating-science journals in
notation that differs between papers, and are rarely applied by the materials
groups who most need them. In practice a laboratory establishes its coating
window by trial and error, one substrate at a time, and the resulting knowledge
stays tacit and local.

`pvcoat` computes wet and dry film thickness and the operability window for both
heads directly from process parameters, implementing the published low-flow,
Landau-Levich and air-entrainment limits together with the validity range each
was derived for. It has no runtime dependencies, accepts quantities in the units
coating practitioners actually use, and returns the dimensionless groups and the
margin to each limit alongside every answer rather than a bare number. Results
computed outside a model's range of validity carry an explicit warning, because a
number computed out of range is still a number, which is the problem.

# Statement of need

This section is deliberately unwritten. A statement of need is a claim that
someone other than the author needed the tool, and that evidence does not yet
exist for pvcoat. It will be written from the issue tracker, the download
statistics and the validation data of v0.2, and not before.

# Implemented models

The low-flow limit follows from the Landau-Levich boundary condition
[@landau1942] applied to a downstream meniscus pinned at the die lip
[@ruschak1976; @higgins1980], giving a minimum wet thickness that rises as the
two-thirds power of the capillary number, so that faster coating makes thin films
harder rather than easier. The coating-bead vacuum window sums the capillary jump
at each meniscus with the lubrication pressure drop under the lips
[@higgins1980; @ding2016], reducing to the capillary model of @ruschak1976 when
the lip lengths vanish. The upper speed bound of every window is dynamic wetting
failure at the contact line [@gutoff1982], which is a property of the contact line
rather than of the head and therefore bounds both coating methods identically.

For blade coating, `pvcoat` implements the evaporation and Landau-Levich regimes
and their crossover [@leberre2009; @huang2024]. The crossover speed is
independent of solids loading, so diluting an ink moves the whole
thickness-versus-speed curve without moving the speed at which the deposited film
is thinnest.

Validity ranges are enforced rather than merely documented
[@carvalho2000; @chang2007; @khandavalli2016].

# Acknowledgements

Funding and institutional acknowledgements will be completed at submission, once
the reporting requirements of the supporting awards have been confirmed.

# References
