"""pvcoat: operability windows and film thickness for slot-die and blade coating.

Given an ink and a coating head, pvcoat answers two questions with published
models rather than rules of thumb: how thick will the film be, wet and dry, and
is that film inside the window where the coating bead or meniscus is stable.

    >>> from pvcoat import Fluid, SlotDieGeometry, slotdie
    >>> ink = Fluid(viscosity="3 cP", surface_tension="30 mN/m", density="1.45 g/cm3")
    >>> die = SlotDieGeometry(gap_downstream="100 um", coating_width="50 mm")
    >>> point = slotdie.evaluate(ink, die, speed="0.01", target_wet_thickness=10e-6)
    >>> point.verdict
    'operable'

Models implemented, each cited in docs/MODELS.md:

* pre-metered wet thickness and dry thickness from solids loading
* the low-flow limit from the Landau-Levich boundary condition
  (Ruschak 1976; Higgins and Scriven 1980)
* the vacuum window of the coating bead, capillary and viscocapillary
* the air-entrainment speed (Gutoff and Kendrick 1982)
* the Landau-Levich film thickness, confined and free meniscus
* the blade-coating evaporation regime and the regime crossover
  (Le Berre, Chen and Baigl 2009)
"""

from __future__ import annotations

from . import blade, dimensionless, limits, references, slotdie, thickness, units, validity
from .fluids import Fluid
from .geometry import BladeGeometry, SlotDieGeometry
from .references import REFERENCES, bibliography, cite
from .report import BladeResult, SlotDieResult, Window
from .units import parse_quantity

__version__ = "0.1.0"

__all__ = [
    "Fluid",
    "SlotDieGeometry",
    "BladeGeometry",
    "SlotDieResult",
    "BladeResult",
    "Window",
    "slotdie",
    "blade",
    "limits",
    "thickness",
    "dimensionless",
    "validity",
    "units",
    "references",
    "REFERENCES",
    "bibliography",
    "cite",
    "parse_quantity",
    "__version__",
]
