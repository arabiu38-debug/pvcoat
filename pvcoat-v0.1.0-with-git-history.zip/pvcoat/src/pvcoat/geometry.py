"""Coating head geometry.

Two heads are described here: a slot die, which is pre-metered (the flow rate
sets the thickness), and a blade, which is self-metered (the speed and the
meniscus set the thickness).

Sign and naming conventions follow Ding, Liu and Harris (2016), Figure 1:
"upstream" is the side the substrate arrives from and where a vacuum box is
attached; "downstream" is the side the wet film leaves on.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .units import parse_quantity


@dataclass(frozen=True)
class SlotDieGeometry:
    """A slot die above a moving substrate.

    Args:
        gap_downstream: Clearance between the downstream lip and the substrate,
            SI m. This is the gap that sets the low-flow limit.
        gap_upstream: Clearance under the upstream lip, SI m. Defaults to
            ``gap_downstream`` (a parallel die).
        lip_length_downstream: Land length of the downstream lip along the
            coating direction, SI m. Sets the viscous pressure drop in the bead.
        lip_length_upstream: Land length of the upstream lip, SI m.
        coating_width: Cross-web width of the coated stripe, SI m. Used only to
            convert a volumetric flow rate into flow per unit width.
        slot_width: Width of the feed slot itself, SI m. Recorded for provenance;
            not used by the operability models in v0.1.
        name: Free-text label carried through reports.
    """

    gap_downstream: float
    coating_width: float
    gap_upstream: Optional[float] = None
    lip_length_downstream: float = 0.0
    lip_length_upstream: float = 0.0
    slot_width: Optional[float] = None
    name: str = ""

    def __post_init__(self) -> None:
        for attribute in (
            "gap_downstream",
            "coating_width",
            "lip_length_downstream",
            "lip_length_upstream",
        ):
            object.__setattr__(self, attribute, parse_quantity(getattr(self, attribute), "length"))
        for attribute in ("gap_upstream", "slot_width"):
            value = getattr(self, attribute)
            if value is not None:
                object.__setattr__(self, attribute, parse_quantity(value, "length"))
        if self.gap_upstream is None:
            object.__setattr__(self, "gap_upstream", self.gap_downstream)
        if self.gap_downstream <= 0 or self.gap_upstream <= 0:
            raise ValueError("coating gaps must be positive")
        if self.coating_width <= 0:
            raise ValueError("coating_width must be positive")
        if self.lip_length_downstream < 0 or self.lip_length_upstream < 0:
            raise ValueError("lip lengths must be non-negative")

    @property
    def is_viscocapillary(self) -> bool:
        """True when lip lengths are set, so viscous terms in the bead are active.

        With both lip lengths zero the package evaluates Ruschak's capillary
        model; with them set it evaluates the viscocapillary model of Higgins
        and Scriven.
        """
        return self.lip_length_downstream > 0 or self.lip_length_upstream > 0

    def describe(self) -> str:
        label = self.name or "slot die"
        return (
            f"{label}: H_down = {self.gap_downstream * 1e6:.4g} um, "
            f"H_up = {self.gap_upstream * 1e6:.4g} um, "
            f"L_down = {self.lip_length_downstream * 1e3:.3g} mm, "
            f"L_up = {self.lip_length_upstream * 1e3:.3g} mm, "
            f"W = {self.coating_width * 1e3:.4g} mm"
        )


@dataclass(frozen=True)
class BladeGeometry:
    """A blade (doctor blade, meniscus applicator) above a moving substrate.

    Args:
        gap: Blade-to-substrate clearance, SI m.
        coating_width: Cross-web width of the coated stripe, SI m.
        meniscus_radius: Radius of curvature of the depositing meniscus, SI m.
            Defaults to ``gap / 2``, the radius of the largest arc that spans the
            gap while remaining tangent to the substrate. Measure it from a
            side-view micrograph when accuracy matters.
        blade_angle_deg: Blade attack angle in degrees. Recorded for provenance;
            not used by the models in v0.1.
        name: Free-text label carried through reports.
    """

    gap: float
    coating_width: float
    meniscus_radius: Optional[float] = None
    blade_angle_deg: Optional[float] = None
    name: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "gap", parse_quantity(self.gap, "length"))
        object.__setattr__(self, "coating_width", parse_quantity(self.coating_width, "length"))
        if self.meniscus_radius is not None:
            object.__setattr__(
                self, "meniscus_radius", parse_quantity(self.meniscus_radius, "length")
            )
        if self.gap <= 0:
            raise ValueError("gap must be positive")
        if self.coating_width <= 0:
            raise ValueError("coating_width must be positive")
        if self.meniscus_radius is not None and self.meniscus_radius <= 0:
            raise ValueError("meniscus_radius must be positive")

    @property
    def effective_meniscus_radius(self) -> float:
        """Meniscus radius used by the Landau-Levich model, SI m."""
        if self.meniscus_radius is not None:
            return self.meniscus_radius
        return self.gap / 2.0

    def describe(self) -> str:
        label = self.name or "blade"
        return (
            f"{label}: G = {self.gap * 1e6:.4g} um, "
            f"R_meniscus = {self.effective_meniscus_radius * 1e6:.4g} um, "
            f"W = {self.coating_width * 1e3:.4g} mm"
        )
