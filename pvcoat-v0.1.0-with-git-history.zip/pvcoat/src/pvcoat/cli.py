"""Command-line interface.

    pvcoat slot-die --viscosity "3 cP" --surface-tension "30 mN/m" \\
        --density "1.45 g/cm3" --gap "100 um" --width "50 mm" \\
        --speed "10 mm/s" --flow "0.5 mL/min"

    pvcoat blade --viscosity "3 cP" --surface-tension "30 mN/m" \\
        --density "1.45 g/cm3" --gap "150 um" --width "50 mm" \\
        --speed "15 mm/s" --molarity 1.4 --molar-mass 632.6 \\
        --film-density "4.1 g/cm3" --evaporation-flux "6e-9 m2/s"

    pvcoat window --viscosity "3 cP" ... --speed-range "2,40,20" \\
        --thickness-range "5,60,20" --out window.csv

Every quantity accepts a unit; a bare number is read as SI.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import List, Optional, Sequence

from . import blade as blade_module
from . import slotdie as slotdie_module
from .fluids import Fluid
from .geometry import BladeGeometry, SlotDieGeometry
from .references import bibliography
from .units import mass_concentration_from_molarity, parse_quantity


def _linspace(start: float, stop: float, count: int) -> List[float]:
    if count < 2:
        return [start]
    step = (stop - start) / (count - 1)
    return [start + step * i for i in range(count)]


def _parse_range(text: str, dimension: str) -> List[float]:
    """Parse 'lo,hi,n' where lo and hi may carry units, into a list of SI values."""
    parts = [chunk.strip() for chunk in text.split(",")]
    if len(parts) != 3:
        raise argparse.ArgumentTypeError(
            "ranges are written 'lo,hi,n', for example '2 mm/s,40 mm/s,20'"
        )
    lo = parse_quantity(parts[0], dimension)
    hi = parse_quantity(parts[1], dimension)
    count = int(float(parts[2]))
    return _linspace(lo, hi, count)


def _add_fluid_arguments(parser: argparse.ArgumentParser) -> None:
    group = parser.add_argument_group("ink")
    group.add_argument("--viscosity", required=True, help="e.g. '3 cP' or '0.003'")
    group.add_argument("--surface-tension", required=True, help="e.g. '30 mN/m'")
    group.add_argument("--density", required=True, help="e.g. '1.45 g/cm3'")
    group.add_argument("--concentration", help="solids mass per volume, e.g. '886 kg/m3'")
    group.add_argument("--molarity", type=float, help="mol/L, an alternative to --concentration")
    group.add_argument("--molar-mass", type=float, help="g/mol, used with --molarity")
    group.add_argument("--film-density", help="dried film density, e.g. '4.1 g/cm3'")
    group.add_argument("--evaporation-flux", help="blade only, e.g. '6e-9 m2/s'")
    group.add_argument("--ink-name", default="", help="label carried through the report")


def _add_limit_arguments(parser: argparse.ArgumentParser) -> None:
    group = parser.add_argument_group("limits")
    group.add_argument(
        "--air-entrainment-model",
        choices=["gutoff_kendrick", "critical_capillary_number"],
        default="gutoff_kendrick",
    )
    group.add_argument(
        "--critical-ca",
        type=float,
        default=1.0,
        help="critical capillary number, used with --air-entrainment-model critical_capillary_number",
    )


def _build_fluid(args: argparse.Namespace) -> Fluid:
    concentration = None
    if args.concentration is not None:
        concentration = args.concentration
    elif args.molarity is not None:
        if args.molar_mass is None:
            raise SystemExit("--molarity needs --molar-mass")
        concentration = mass_concentration_from_molarity(args.molarity, args.molar_mass)
    return Fluid(
        viscosity=args.viscosity,
        surface_tension=args.surface_tension,
        density=args.density,
        solids_concentration=concentration,
        film_density=args.film_density,
        evaporation_flux=args.evaporation_flux,
        name=args.ink_name,
    )


def _slot_die_geometry(args: argparse.Namespace) -> SlotDieGeometry:
    return SlotDieGeometry(
        gap_downstream=args.gap,
        gap_upstream=args.gap_upstream,
        lip_length_downstream=args.lip_downstream or 0.0,
        lip_length_upstream=args.lip_upstream or 0.0,
        coating_width=args.width,
        slot_width=args.slot_width,
        name=args.head_name,
    )


def _command_slot_die(args: argparse.Namespace) -> int:
    fluid = _build_fluid(args)
    geometry = _slot_die_geometry(args)
    if (args.flow is None) == (args.wet_thickness is None):
        raise SystemExit("give exactly one of --flow or --wet-thickness")
    result = slotdie_module.evaluate(
        fluid,
        geometry,
        speed=args.speed,
        flow_rate=args.flow,
        target_wet_thickness=args.wet_thickness,
        air_entrainment_model=args.air_entrainment_model,
        critical_capillary_number=args.critical_ca,
    )
    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
    else:
        print(fluid.describe())
        print(geometry.describe())
        print()
        print(result.render())
    return 0 if result.verdict != "not operable" else 2


def _command_blade(args: argparse.Namespace) -> int:
    fluid = _build_fluid(args)
    geometry = BladeGeometry(
        gap=args.gap,
        coating_width=args.width,
        meniscus_radius=args.meniscus_radius,
        name=args.head_name,
    )
    result = blade_module.evaluate(
        fluid,
        geometry,
        speed=args.speed,
        air_entrainment_model=args.air_entrainment_model,
        critical_capillary_number=args.critical_ca,
    )
    if args.json:
        print(json.dumps(result.to_dict(), indent=2))
    else:
        print(fluid.describe())
        print(geometry.describe())
        print()
        print(result.render())
    return 0 if result.verdict != "not operable" else 2


def _command_window(args: argparse.Namespace) -> int:
    fluid = _build_fluid(args)
    speeds = _parse_range(args.speed_range, "velocity")
    if args.head == "slot-die":
        geometry = _slot_die_geometry(args)
        thicknesses = _parse_range(args.thickness_range, "length")
        win = slotdie_module.window(
            fluid,
            geometry,
            speeds,
            thicknesses,
            air_entrainment_model=args.air_entrainment_model,
            critical_capillary_number=args.critical_ca,
        )
    else:
        geometry = BladeGeometry(
            gap=args.gap, coating_width=args.width, meniscus_radius=args.meniscus_radius
        )
        win = blade_module.window(
            fluid,
            geometry,
            speeds,
            air_entrainment_model=args.air_entrainment_model,
            critical_capillary_number=args.critical_ca,
        )
    csv = win.to_csv()
    if args.out:
        with open(args.out, "w", encoding="utf-8") as handle:
            handle.write(csv)
        print(win.summary())
        print(f"written to {args.out}")
    else:
        sys.stdout.write(csv)
    return 0


def _command_references(args: argparse.Namespace) -> int:
    for entry in bibliography():
        print(f"{entry.key}: {entry}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pvcoat",
        description=(
            "Operability windows and film thickness for slot-die and blade coating, "
            "from published models."
        ),
    )
    from . import __version__

    parser.add_argument("--version", action="version", version=f"pvcoat {__version__}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    slot = subparsers.add_parser("slot-die", help="evaluate one slot-die process point")
    _add_fluid_arguments(slot)
    _add_limit_arguments(slot)
    head = slot.add_argument_group("coating head")
    head.add_argument("--gap", required=True, help="downstream coating gap, e.g. '100 um'")
    head.add_argument("--gap-upstream", help="defaults to --gap")
    head.add_argument("--lip-downstream", help="downstream lip land length, e.g. '1 mm'")
    head.add_argument("--lip-upstream", help="upstream lip land length")
    head.add_argument("--slot-width", help="feed slot width, recorded only")
    head.add_argument("--width", required=True, help="coated width, e.g. '50 mm'")
    head.add_argument("--head-name", default="")
    process = slot.add_argument_group("process")
    process.add_argument("--speed", required=True, help="substrate speed, e.g. '10 mm/s'")
    process.add_argument("--flow", help="pump flow rate, e.g. '0.5 mL/min'")
    process.add_argument("--wet-thickness", help="target wet thickness, e.g. '12 um'")
    slot.add_argument("--json", action="store_true", help="machine-readable output")
    slot.set_defaults(func=_command_slot_die)

    blade = subparsers.add_parser("blade", help="evaluate one blade process point")
    _add_fluid_arguments(blade)
    _add_limit_arguments(blade)
    head = blade.add_argument_group("coating head")
    head.add_argument("--gap", required=True, help="blade gap, e.g. '150 um'")
    head.add_argument("--meniscus-radius", help="defaults to half the gap")
    head.add_argument("--width", required=True, help="coated width, e.g. '50 mm'")
    head.add_argument("--head-name", default="")
    blade.add_argument("--speed", required=True, help="substrate speed, e.g. '15 mm/s'")
    blade.add_argument("--json", action="store_true")
    blade.set_defaults(func=_command_blade)

    win = subparsers.add_parser("window", help="sweep a grid and write it as CSV")
    _add_fluid_arguments(win)
    _add_limit_arguments(win)
    win.add_argument("--head", choices=["slot-die", "blade"], default="slot-die")
    win.add_argument("--gap", required=True)
    win.add_argument("--gap-upstream")
    win.add_argument("--lip-downstream")
    win.add_argument("--lip-upstream")
    win.add_argument("--slot-width")
    win.add_argument("--meniscus-radius")
    win.add_argument("--width", required=True)
    win.add_argument("--head-name", default="")
    win.add_argument(
        "--speed-range", required=True, help="'lo,hi,n', e.g. '2 mm/s,40 mm/s,20'"
    )
    win.add_argument(
        "--thickness-range",
        help="'lo,hi,n' of target wet thickness, slot-die only, e.g. '5 um,60 um,20'",
    )
    win.add_argument("--out", help="CSV path; stdout if omitted")
    win.set_defaults(func=_command_window)

    refs = subparsers.add_parser("references", help="print the bibliography")
    refs.set_defaults(func=_command_references)

    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == "window" and args.head == "slot-die" and not args.thickness_range:
        parser.error("--thickness-range is required for a slot-die window")
    return args.func(args)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
