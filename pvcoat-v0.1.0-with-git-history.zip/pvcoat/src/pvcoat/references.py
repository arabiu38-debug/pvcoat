"""Bibliography for the models implemented in pvcoat.

Every model function exposes the key(s) of the work it implements through its
``.references`` attribute, so a result can always be traced to a paper.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List


@dataclass(frozen=True)
class Reference:
    """One bibliographic entry."""

    key: str
    authors: str
    year: int
    title: str
    venue: str
    doi: str = ""

    def __str__(self) -> str:
        tail = f" https://doi.org/{self.doi}" if self.doi else ""
        return f"{self.authors} ({self.year}). {self.title}. {self.venue}.{tail}"


_ENTRIES: List[Reference] = [
    Reference(
        "landau1942",
        "Landau, L. D. and Levich, B. G.",
        1942,
        "Dragging of a liquid by a moving plate",
        "Acta Physicochimica URSS 17, 42-54",
    ),
    Reference(
        "ruschak1976",
        "Ruschak, K. J.",
        1976,
        "Limiting flow in a pre-metered coating device",
        "Chemical Engineering Science 31(11), 1057-1060",
        "10.1016/0009-2509(76)87026-1",
    ),
    Reference(
        "higgins1980",
        "Higgins, B. G. and Scriven, L. E.",
        1980,
        "Capillary pressure and viscous pressure drop set bounds on coating bead operability",
        "Chemical Engineering Science 35(3), 673-682",
        "10.1016/0009-2509(80)80018-6",
    ),
    Reference(
        "gutoff1982",
        "Gutoff, E. B. and Kendrick, C. E.",
        1982,
        "Dynamic contact angles",
        "AIChE Journal 28(3), 459-466",
        "10.1002/aic.690280314",
    ),
    Reference(
        "lee1992",
        "Lee, K. Y., Liu, L. D. and Liu, T.-J.",
        1992,
        "Minimum wet thickness in extrusion slot coating",
        "Chemical Engineering Science 47(7), 1703-1713",
        "10.1016/0009-2509(92)85018-7",
    ),
    Reference(
        "carvalho2000",
        "Carvalho, M. S. and Kheshgi, H. S.",
        2000,
        "Low-flow limit in slot coating: theory and experiments",
        "AIChE Journal 46(10), 1907-1917",
        "10.1002/aic.690461003",
    ),
    Reference(
        "chang2007",
        "Chang, Y.-R., Chang, H.-M., Lin, C.-F., Liu, T.-J. and Wu, P.-Y.",
        2007,
        "Three minimum wet thickness regions of slot die coating",
        "Journal of Colloid and Interface Science 308(1), 222-230",
        "10.1016/j.jcis.2006.11.054",
    ),
    Reference(
        "leberre2009",
        "Le Berre, M., Chen, Y. and Baigl, D.",
        2009,
        "From convective assembly to Landau-Levich deposition of multilayered "
        "phospholipid films of controlled thickness",
        "Langmuir 25(5), 2554-2557",
        "10.1021/la803646e",
    ),
    Reference(
        "ding2016",
        "Ding, X., Liu, J. and Harris, T. A. L.",
        2016,
        "A review of the operating limits in slot die coating processes",
        "AIChE Journal 62(7), 2508-2524",
        "10.1002/aic.15268",
    ),
    Reference(
        "khandavalli2016",
        "Khandavalli, S. and Rothstein, J. P.",
        2016,
        "The effect of shear-thickening on the stability of slot-die coating",
        "AIChE Journal 62(12), 4536-4547",
        "10.1002/aic.15336",
    ),
    Reference(
        "huang2024",
        "Huang, Y. et al.",
        2024,
        "Meniscus-modulated blade coating enables high-quality alpha-phase "
        "formamidinium lead triiodide crystals and efficient perovskite minimodules",
        "Joule 8(8), 2313-2326",
        "10.1016/j.joule.2024.06.008",
    ),
]

REFERENCES: Dict[str, Reference] = {entry.key: entry for entry in _ENTRIES}


def cite(*keys: str) -> str:
    """Return a formatted citation block for one or more reference keys."""
    return "\n".join(str(REFERENCES[key]) for key in keys)


def bibliography(keys: Iterable[str] = ()) -> List[Reference]:
    """Return reference objects for ``keys``, or the whole bibliography if empty."""
    keys = list(keys)
    if not keys:
        return list(_ENTRIES)
    return [REFERENCES[key] for key in keys]
