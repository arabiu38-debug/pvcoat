"""The coating fluid.

A :class:`Fluid` holds the four properties every model in this package needs
(viscosity, surface tension, density, and how much solid is in the ink) plus an
optional evaporation flux for the blade-coating evaporation regime.

All constructor arguments accept either a number in SI or a string with a unit,
so both of these are the same ink::

    Fluid(viscosity=0.003, surface_tension=0.030, density=1450)
    Fluid(viscosity="3 cP", surface_tension="30 mN/m", density="1.45 g/cm3")
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .units import mass_concentration_from_molarity, parse_quantity


@dataclass(frozen=True)
class Fluid:
    """A Newtonian coating ink.

    Args:
        viscosity: Dynamic viscosity, SI Pa s. Shear-rate dependent inks must be
            evaluated at a representative shear rate by the caller; see
            :meth:`representative_shear_rate` and docs/LIMITATIONS.md.
        surface_tension: Liquid-air surface tension, SI N/m.
        density: Solution density, SI kg/m3.
        solids_concentration: Mass of solid per volume of *solution*, SI kg/m3.
            Optional; needed only for dry-thickness calculations.
        film_density: Density of the dried film, SI kg/m3. Optional; needed only
            for dry-thickness calculations. Defaults to the crystal density the
            caller supplies, not to the solution density.
        evaporation_flux: Solvent volume leaving the meniscus per unit blade
            length per second, SI m2/s. Optional; needed only for the blade
            evaporation regime.
        name: Free-text label carried through reports.
    """

    viscosity: float
    surface_tension: float
    density: float
    solids_concentration: Optional[float] = None
    film_density: Optional[float] = None
    evaporation_flux: Optional[float] = None
    name: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "viscosity", parse_quantity(self.viscosity, "viscosity"))
        object.__setattr__(
            self, "surface_tension", parse_quantity(self.surface_tension, "surface_tension")
        )
        object.__setattr__(self, "density", parse_quantity(self.density, "density"))
        if self.solids_concentration is not None:
            object.__setattr__(
                self,
                "solids_concentration",
                parse_quantity(self.solids_concentration, "concentration"),
            )
        if self.film_density is not None:
            object.__setattr__(self, "film_density", parse_quantity(self.film_density, "density"))
        if self.evaporation_flux is not None:
            object.__setattr__(
                self,
                "evaporation_flux",
                parse_quantity(self.evaporation_flux, "evaporation_flux"),
            )
        for attribute in ("viscosity", "surface_tension", "density"):
            if getattr(self, attribute) <= 0:
                raise ValueError(f"{attribute} must be positive")
        if self.solids_concentration is not None and self.solids_concentration < 0:
            raise ValueError("solids_concentration must be non-negative")
        if self.film_density is not None and self.film_density <= 0:
            raise ValueError("film_density must be positive")

    @classmethod
    def from_molarity(
        cls,
        viscosity,
        surface_tension,
        density,
        molarity_mol_per_l: float,
        molar_mass_g_per_mol: float,
        film_density,
        **kwargs,
    ) -> "Fluid":
        """Build a :class:`Fluid` from a molar ink recipe.

        Perovskite precursors are specified in molarity, so this converts once
        rather than making every caller do it.
        """
        concentration = mass_concentration_from_molarity(
            molarity_mol_per_l, molar_mass_g_per_mol
        )
        return cls(
            viscosity=viscosity,
            surface_tension=surface_tension,
            density=density,
            solids_concentration=concentration,
            film_density=film_density,
            **kwargs,
        )

    @property
    def solids_volume_fraction(self) -> float:
        """Volume of dry film per volume of wet ink, dimensionless.

        This is the shrinkage factor between wet and dry thickness. It assumes a
        fully dense film: real perovskite films with residual porosity are
        thicker than this predicts, which is a floor rather than an estimate.
        """
        if self.solids_concentration is None or self.film_density is None:
            raise ValueError(
                "solids_concentration and film_density are both required for "
                "dry-thickness calculations"
            )
        return self.solids_concentration / self.film_density

    @property
    def capillary_length(self) -> float:
        """Capillary length sqrt(sigma / rho g), SI m.

        Sets the meniscus scale for a free (unconfined) meniscus, as in dip
        coating and in the free-meniscus form of the Landau-Levich equation.
        """
        g = 9.80665
        return (self.surface_tension / (self.density * g)) ** 0.5

    def representative_shear_rate(self, speed: float, gap: float) -> float:
        """Nominal shear rate U/H in the coating gap, SI 1/s.

        Khandavalli and Rothstein (2016) evaluate the capillary number of a
        non-Newtonian ink at this shear rate. For a shear-thinning perovskite
        ink, measure the viscosity here and pass that value to the constructor.
        """
        if gap <= 0:
            raise ValueError("gap must be positive")
        return speed / gap

    def describe(self) -> str:
        label = self.name or "ink"
        parts = [
            f"{label}: mu = {self.viscosity * 1e3:.3g} mPa s",
            f"sigma = {self.surface_tension * 1e3:.3g} mN/m",
            f"rho = {self.density:.4g} kg/m3",
        ]
        if self.solids_concentration is not None:
            parts.append(f"c = {self.solids_concentration:.4g} kg/m3")
        if self.film_density is not None:
            parts.append(f"rho_film = {self.film_density:.4g} kg/m3")
        return ", ".join(parts)
