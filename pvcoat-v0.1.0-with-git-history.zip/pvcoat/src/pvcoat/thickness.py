"""Wet and dry film thickness from process parameters.

Slot-die coating is pre-metered: the pump sets the thickness, and the gap sets
whether that thickness is achievable. These functions do the metering
arithmetic; the operability limits in :mod:`pvcoat.limits` do the rest.
"""

from __future__ import annotations

from .fluids import Fluid


def flow_per_width(flow_rate: float, coating_width: float) -> float:
    """q = Q / W, the volumetric flow rate per unit coating width, SI m2/s."""
    if coating_width <= 0:
        raise ValueError("coating_width must be positive")
    if flow_rate < 0:
        raise ValueError("flow_rate must be non-negative")
    return flow_rate / coating_width


def wet_thickness(flow_rate: float, coating_width: float, speed: float) -> float:
    """h_wet = Q / (W U), the pre-metered wet film thickness, SI m.

    Exact by mass conservation for an incompressible ink, provided every drop
    pumped ends up on the substrate. It says nothing about whether the coating
    is stable: for that, compare against
    :func:`pvcoat.limits.low_flow_limit`.

    Args:
        flow_rate: Volumetric flow rate through the die, SI m3/s.
        coating_width: Coated width, SI m.
        speed: Substrate speed, SI m/s.
    """
    if speed <= 0:
        raise ValueError("speed must be positive")
    return flow_per_width(flow_rate, coating_width) / speed


wet_thickness.references = ("ruschak1976",)


def flow_rate_for_wet_thickness(
    target_wet_thickness: float, coating_width: float, speed: float
) -> float:
    """Q = h_wet W U, the pump setting for a target wet thickness, SI m3/s."""
    if target_wet_thickness < 0:
        raise ValueError("target_wet_thickness must be non-negative")
    if speed <= 0:
        raise ValueError("speed must be positive")
    return target_wet_thickness * coating_width * speed


def dry_thickness(wet: float, fluid: Fluid) -> float:
    """h_dry = h_wet * (c / rho_film), SI m.

    The shrinkage factor is the solids volume fraction: mass of solid per volume
    of solution, divided by the density of the dried solid. It assumes a fully
    dense film and no loss of solid during drying, so it is a lower bound on the
    thickness of a porous film.
    """
    if wet < 0:
        raise ValueError("wet thickness must be non-negative")
    return wet * fluid.solids_volume_fraction


def wet_thickness_for_dry(target_dry: float, fluid: Fluid) -> float:
    """Wet thickness needed to leave ``target_dry`` after drying, SI m."""
    if target_dry < 0:
        raise ValueError("target_dry must be non-negative")
    return target_dry / fluid.solids_volume_fraction


def flow_rate_for_dry_thickness(
    target_dry: float, fluid: Fluid, coating_width: float, speed: float
) -> float:
    """Pump setting for a target dry thickness, SI m3/s.

    The usual working question: 'I want 600 nm of perovskite at 10 mm/s over a
    50 mm stripe; what do I set the syringe pump to?'
    """
    return flow_rate_for_wet_thickness(
        wet_thickness_for_dry(target_dry, fluid), coating_width, speed
    )
