"""Slot-die coating: evaluate a process point, or sweep an operability window."""

from __future__ import annotations

from typing import Iterable, List, Optional, Sequence

from .dimensionless import capillary_number, reynolds_number
from .fluids import Fluid
from .geometry import SlotDieGeometry
from .limits import (
    air_entrainment_speed,
    low_flow_limit,
    minimum_thickness_no_vacuum,
    vacuum_window,
)
from .report import SlotDieResult, Window
from .thickness import dry_thickness, flow_per_width, wet_thickness
from .units import parse_quantity
from .validity import check_viscocapillary


def evaluate(
    fluid: Fluid,
    geometry: SlotDieGeometry,
    speed: float,
    flow_rate: Optional[float] = None,
    target_wet_thickness: Optional[float] = None,
    air_entrainment_model: str = "gutoff_kendrick",
    critical_capillary_number: float = 1.0,
) -> SlotDieResult:
    """Evaluate one slot-die process point against every implemented limit.

    Give either ``flow_rate`` (SI m3/s, what the pump is set to) or
    ``target_wet_thickness`` (SI m, what you want on the substrate); the other
    follows from h_wet = Q / (W U).

    Returns a :class:`~pvcoat.report.SlotDieResult` carrying the thicknesses,
    the dimensionless groups, the margin to each limit, the vacuum window, and
    any validity warnings.
    """
    speed = parse_quantity(speed, "velocity")
    if speed <= 0:
        raise ValueError("speed must be positive")
    if (flow_rate is None) == (target_wet_thickness is None):
        raise ValueError("give exactly one of flow_rate or target_wet_thickness")

    if flow_rate is None:
        wet = parse_quantity(target_wet_thickness, "length")
        flow_rate = wet * geometry.coating_width * speed
    else:
        flow_rate = parse_quantity(flow_rate, "flow")
        wet = wet_thickness(flow_rate, geometry.coating_width, speed)
    if wet <= 0:
        raise ValueError("wet thickness must be positive")

    ca = capillary_number(fluid.viscosity, speed, fluid.surface_tension)
    q = flow_per_width(flow_rate, geometry.coating_width)
    re = reynolds_number(fluid.density, q, fluid.viscosity)

    dry = None
    if fluid.solids_concentration is not None and fluid.film_density is not None:
        dry = dry_thickness(wet, fluid)

    validity = check_viscocapillary(ca, re, wet / geometry.gap_downstream)
    result = SlotDieResult(
        speed=speed,
        flow_rate=flow_rate,
        wet_thickness=wet,
        dry_thickness=dry,
        capillary_number=ca,
        reynolds_number=re,
        low_flow_limit=low_flow_limit(fluid, geometry, speed),
        minimum_thickness_no_vacuum=minimum_thickness_no_vacuum(fluid, geometry, speed),
        vacuum_window=vacuum_window(fluid, geometry, speed, wet),
        air_entrainment_speed=air_entrainment_speed(
            fluid, air_entrainment_model, critical_capillary_number
        ),
        validity=validity,
        references=[
            "ruschak1976",
            "higgins1980",
            "gutoff1982",
            "carvalho2000",
            "ding2016",
        ],
    )
    if not geometry.is_viscocapillary:
        result.notes.append(
            "Lip lengths are zero, so this is Ruschak's capillary model with no "
            "viscous terms in the bead. Set lip_length_downstream and "
            "lip_length_upstream for the viscocapillary model."
        )
    if result.needs_vacuum:
        result.notes.append(
            "This point needs a vacuum box; the window's lower bound is positive."
        )
    return result


def window(
    fluid: Fluid,
    geometry: SlotDieGeometry,
    speeds: Sequence[float],
    wet_thicknesses: Sequence[float],
    **kwargs,
) -> Window:
    """Sweep speed against target wet thickness and label every point.

    Returns a :class:`~pvcoat.report.Window` whose ``points`` carry the verdict
    and the margins, ready for a contour plot or a CSV.
    """
    points: List[dict] = []
    for speed in speeds:
        for wet in wet_thicknesses:
            result = evaluate(
                fluid, geometry, speed, target_wet_thickness=wet, **kwargs
            )
            points.append(
                {
                    "speed_m_s": speed,
                    "wet_thickness_m": wet,
                    "dry_thickness_m": result.dry_thickness,
                    "flow_rate_m3_s": result.flow_rate,
                    "capillary_number": result.capillary_number,
                    "reynolds_number": result.reynolds_number,
                    "low_flow_limit_m": result.low_flow_limit,
                    "low_flow_margin": result.low_flow_margin,
                    "speed_margin": result.speed_margin,
                    "vacuum_min_pa": result.vacuum_window[0],
                    "vacuum_max_pa": result.vacuum_window[1],
                    "verdict": result.verdict,
                    "warning_codes": ";".join(w.code for w in result.validity),
                }
            )
    return Window(
        points=points,
        axes={"speed_m_s": list(speeds), "wet_thickness_m": list(wet_thicknesses)},
        kind="slot-die",
    )


def limit_curve(
    fluid: Fluid, geometry: SlotDieGeometry, speeds: Iterable[float]
) -> List[dict]:
    """The two thickness limits as a function of speed, for plotting.

    Returns one row per speed with the low-flow limit and the zero-vacuum
    minimum thickness, both SI m.
    """
    rows = []
    for speed in speeds:
        rows.append(
            {
                "speed_m_s": speed,
                "low_flow_limit_m": low_flow_limit(fluid, geometry, speed),
                "min_thickness_no_vacuum_m": minimum_thickness_no_vacuum(
                    fluid, geometry, speed
                ),
                "capillary_number": capillary_number(
                    fluid.viscosity, speed, fluid.surface_tension
                ),
            }
        )
    return rows
