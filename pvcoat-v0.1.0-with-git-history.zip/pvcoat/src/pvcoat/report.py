"""Result objects.

The evaluate functions return one of these rather than a bare number, so that
the answer arrives with the dimensionless groups it depends on, the margin to
each limit, the validity warnings, and the references behind it.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Dict, List, Optional

from .units import to_mbar, to_mm_per_s, to_nm, to_um
from .validity import ValidityReport

_VERDICTS = ("operable", "marginal", "not operable")


@dataclass
class SlotDieResult:
    """One slot-die process point, evaluated against every limit."""

    speed: float
    flow_rate: float
    wet_thickness: float
    dry_thickness: Optional[float]
    capillary_number: float
    reynolds_number: float
    low_flow_limit: float
    minimum_thickness_no_vacuum: float
    vacuum_window: tuple
    air_entrainment_speed: float
    validity: ValidityReport = field(default_factory=ValidityReport)
    references: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @property
    def low_flow_margin(self) -> float:
        """h_wet / h_min. Above 1 the bead sustains the film; 1.5 or more is comfortable."""
        if self.low_flow_limit <= 0:
            return float("inf")
        return self.wet_thickness / self.low_flow_limit

    @property
    def speed_margin(self) -> float:
        """U_ae / U. Above 1 the contact line holds."""
        if self.speed <= 0:
            return float("inf")
        return self.air_entrainment_speed / self.speed

    @property
    def needs_vacuum(self) -> bool:
        return self.vacuum_window[0] > 0

    @property
    def verdict(self) -> str:
        if self.validity.has_error:
            return "not operable"
        if self.low_flow_margin < 1.0 or self.speed_margin < 1.0:
            return "not operable"
        if self.low_flow_margin < 1.5 or self.speed_margin < 1.5:
            return "marginal"
        return "operable"

    def to_dict(self) -> Dict:
        data = asdict(self)
        data.pop("validity")
        data["vacuum_window"] = list(self.vacuum_window)
        data["low_flow_margin"] = self.low_flow_margin
        data["speed_margin"] = self.speed_margin
        data["needs_vacuum"] = self.needs_vacuum
        data["verdict"] = self.verdict
        data["warnings"] = [
            {"code": w.code, "severity": w.severity, "message": w.message}
            for w in self.validity
        ]
        return data

    def render(self) -> str:
        lines = [
            "slot-die process point",
            f"  speed                    {to_mm_per_s(self.speed):.4g} mm/s",
            f"  flow rate                {self.flow_rate * 6e7:.4g} mL/min",
            f"  Ca                       {self.capillary_number:.3g}",
            f"  Re                       {self.reynolds_number:.3g}",
            "",
            f"  wet thickness            {to_um(self.wet_thickness):.4g} um",
        ]
        if self.dry_thickness is not None:
            lines.append(f"  dry thickness            {to_nm(self.dry_thickness):.4g} nm")
        lines += [
            "",
            f"  low-flow limit h_min     {to_um(self.low_flow_limit):.4g} um"
            f"   (margin h_wet/h_min = {self.low_flow_margin:.2f})",
            f"  min thickness, no vacuum {to_um(self.minimum_thickness_no_vacuum):.4g} um",
            f"  vacuum window            {to_mbar(self.vacuum_window[0]):.4g}"
            f" to {to_mbar(self.vacuum_window[1]):.4g} mbar",
            f"  air entrainment speed    {to_mm_per_s(self.air_entrainment_speed):.4g} mm/s"
            f"   (margin U_ae/U = {self.speed_margin:.2f})",
            "",
            f"  verdict                  {self.verdict}",
        ]
        if len(self.validity):
            lines += ["", "  validity:"]
            lines += [f"    {w}" for w in self.validity]
        if self.notes:
            lines += ["", "  notes:"]
            lines += [f"    {note}" for note in self.notes]
        return "\n".join(lines)


@dataclass
class BladeResult:
    """One blade-coating process point."""

    speed: float
    wet_thickness: float
    dry_thickness: float
    regime: str
    capillary_number: float
    crossover_speed: Optional[float]
    minimum_dry_thickness: Optional[float]
    air_entrainment_speed: float
    validity: ValidityReport = field(default_factory=ValidityReport)
    references: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @property
    def speed_margin(self) -> float:
        if self.speed <= 0:
            return float("inf")
        return self.air_entrainment_speed / self.speed

    @property
    def verdict(self) -> str:
        if self.validity.has_error:
            return "not operable"
        if self.speed_margin < 1.0:
            return "not operable"
        if self.speed_margin < 1.5:
            return "marginal"
        return "operable"

    def to_dict(self) -> Dict:
        data = asdict(self)
        data.pop("validity")
        data["speed_margin"] = self.speed_margin
        data["verdict"] = self.verdict
        data["warnings"] = [
            {"code": w.code, "severity": w.severity, "message": w.message}
            for w in self.validity
        ]
        return data

    def render(self) -> str:
        lines = [
            "blade process point",
            f"  speed                    {to_mm_per_s(self.speed):.4g} mm/s",
            f"  Ca                       {self.capillary_number:.3g}",
            f"  governing regime         {self.regime}",
            "",
            f"  wet thickness (LL)       {to_um(self.wet_thickness):.4g} um",
            f"  dry thickness            {to_nm(self.dry_thickness):.4g} nm",
        ]
        if self.crossover_speed is not None:
            lines.append(
                f"  regime crossover U*      {to_mm_per_s(self.crossover_speed):.4g} mm/s"
            )
        if self.minimum_dry_thickness is not None:
            lines.append(
                f"  thinnest film at U*      {to_nm(self.minimum_dry_thickness):.4g} nm"
            )
        lines += [
            f"  air entrainment speed    {to_mm_per_s(self.air_entrainment_speed):.4g} mm/s"
            f"   (margin U_ae/U = {self.speed_margin:.2f})",
            "",
            f"  verdict                  {self.verdict}",
        ]
        if len(self.validity):
            lines += ["", "  validity:"]
            lines += [f"    {w}" for w in self.validity]
        if self.notes:
            lines += ["", "  notes:"]
            lines += [f"    {note}" for note in self.notes]
        return "\n".join(lines)


@dataclass
class Window:
    """A grid of process points forming an operability window."""

    points: List[Dict]
    axes: Dict[str, List[float]]
    kind: str = "slot-die"

    def operable(self) -> List[Dict]:
        return [p for p in self.points if p["verdict"] == "operable"]

    def to_csv(self) -> str:
        if not self.points:
            return ""
        columns = [
            key
            for key in self.points[0]
            if not isinstance(self.points[0][key], (list, dict))
        ]
        lines = [",".join(columns)]
        for point in self.points:
            lines.append(",".join(_csv_cell(point[key]) for key in columns))
        return "\n".join(lines) + "\n"

    def summary(self) -> str:
        total = len(self.points)
        good = len(self.operable())
        return (
            f"{self.kind} window: {good} of {total} grid points operable "
            f"({100.0 * good / total:.1f}%)"
            if total
            else f"{self.kind} window: empty"
        )


def _csv_cell(value) -> str:
    if isinstance(value, float):
        return f"{value:.6g}"
    text = str(value)
    return f'"{text}"' if "," in text else text
