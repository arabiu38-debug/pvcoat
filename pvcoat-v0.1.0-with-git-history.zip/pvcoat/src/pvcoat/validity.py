"""Validity checks.

Every model in this package has a range it was derived and tested in. A number
computed outside that range is still a number, which is the problem. These
checks attach an explicit warning to any result computed outside the range, so a
value that should not be trusted does not travel silently into a lab notebook.

Thresholds are module constants, so that a user who has their own evidence about
where a model holds can move them.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

#: Above this capillary number the viscocapillary low-flow limit departs from
#: experiment (Carvalho and Kheshgi 2000; Chang et al. 2007).
CA_VISCOCAPILLARY_MAX = 1.0

#: Above this Reynolds number inertia distorts the bead (Chang et al. 2007
#: report a transition near Re = 20; this package warns an order earlier).
RE_VISCOCAPILLARY_MAX = 1.0

#: Normalised wet thickness h/H at which experiment shows the low-flow limit
#: plateauing rather than following Ca^(2/3) (Khandavalli and Rothstein 2016
#: measure a plateau at h/H between about 0.44 and 0.55).
PLATEAU_THICKNESS_RATIO = 0.44

#: A wet film thicker than this fraction of the gap floods the bead in practice.
FLOODING_THICKNESS_RATIO = 1.0


@dataclass
class Warning_:
    """One validity concern about a computed result."""

    code: str
    message: str
    severity: str = "warning"  # "warning" or "error"

    def __str__(self) -> str:
        return f"[{self.severity}] {self.code}: {self.message}"


@dataclass
class ValidityReport:
    """Collected validity concerns for one process point."""

    warnings: List[Warning_] = field(default_factory=list)

    def add(self, code: str, message: str, severity: str = "warning") -> None:
        self.warnings.append(Warning_(code, message, severity))

    @property
    def ok(self) -> bool:
        """True when nothing was flagged."""
        return not self.warnings

    @property
    def has_error(self) -> bool:
        return any(w.severity == "error" for w in self.warnings)

    def __iter__(self):
        return iter(self.warnings)

    def __len__(self) -> int:
        return len(self.warnings)

    def render(self) -> str:
        if not self.warnings:
            return "no validity concerns"
        return "\n".join(str(w) for w in self.warnings)


def check_viscocapillary(
    capillary: float,
    reynolds: float,
    thickness_ratio: float = None,
) -> ValidityReport:
    """Flag a process point that leaves the range of the viscocapillary models.

    Args:
        capillary: Ca = mu U / sigma.
        reynolds: Re = rho q / mu.
        thickness_ratio: h_wet / H_down, if known.
    """
    report = ValidityReport()
    if capillary > CA_VISCOCAPILLARY_MAX:
        report.add(
            "CA_HIGH",
            f"Ca = {capillary:.3g} exceeds {CA_VISCOCAPILLARY_MAX:g}. The "
            "Landau-Levich boundary condition underlying the low-flow limit and "
            "the vacuum window is derived for Ca << 1; above Ca ~ 1 the measured "
            "minimum wet thickness stops following Ca^(2/3) and eventually falls "
            "with speed. Treat the limit as indicative only.",
        )
    if reynolds > RE_VISCOCAPILLARY_MAX:
        report.add(
            "RE_HIGH",
            f"Re = {reynolds:.3g} exceeds {RE_VISCOCAPILLARY_MAX:g}. Inertia "
            "lengthens the coating bead and pushes the downstream meniscus away "
            "from the low-flow limit, so the model is conservative here.",
        )
    if thickness_ratio is not None:
        if thickness_ratio > FLOODING_THICKNESS_RATIO:
            report.add(
                "FLOODING",
                f"h_wet / H_down = {thickness_ratio:.3g} exceeds 1: the metered "
                "film is thicker than the gap, so the bead floods.",
                severity="error",
            )
        elif thickness_ratio < 0.02:
            report.add(
                "VERY_THIN",
                f"h_wet / H_down = {thickness_ratio:.3g}. Very thin films relative "
                "to the gap sit deep in the region where the low-flow limit "
                "governs; check the margin below.",
            )
    return report


def check_landau_levich(capillary: float) -> ValidityReport:
    """Flag a Landau-Levich evaluation outside its derivation range."""
    report = ValidityReport()
    if capillary > CA_VISCOCAPILLARY_MAX:
        report.add(
            "CA_HIGH",
            f"Ca = {capillary:.3g} exceeds {CA_VISCOCAPILLARY_MAX:g}; the "
            "Landau-Levich result is an asymptotic low-Ca solution.",
        )
    return report
