"""Published operating limits for slot-die and blade coating.

Each function implements one published model, states its equation and its
validity range in the docstring, and carries the reference key(s) of the work it
comes from on a ``.references`` attribute. docs/MODELS.md gives the symbol
table, the derivations, and the assumptions in full.

Nothing here is fitted or tuned. Where a model needs a coefficient that the
original paper reports empirically, the coefficient is a module-level constant
so that it can be overridden with the user's own measurement.
"""

from __future__ import annotations

from typing import Callable, Optional, Tuple

from .dimensionless import capillary_number
from .fluids import Fluid
from .geometry import BladeGeometry, SlotDieGeometry

#: Landau-Levich prefactor for a meniscus of finite radius R: h = C R Ca^(2/3).
#: Landau and Levich (1942); the value 1.34 as used for confined menisci by
#: Ruschak (1976) and Le Berre, Chen and Baigl (2009).
LANDAU_LEVICH_CONFINED = 1.34

#: Landau-Levich-Derjaguin prefactor for a free meniscus, where the capillary
#: length replaces R: h = 0.94 l_c Ca^(2/3). Landau and Levich (1942).
LANDAU_LEVICH_FREE = 0.94

#: Dimensional air-entrainment correlation of Gutoff and Kendrick (1982),
#: U_ae = A mu^n with mu in mPa s and U_ae in m/s.
AIR_ENTRAINMENT_PREFACTOR = 6.9
AIR_ENTRAINMENT_EXPONENT = -0.67


def _bisect(f: Callable[[float], float], lo: float, hi: float, tol: float = 1e-15) -> float:
    """Root of a monotone decreasing ``f`` on ``[lo, hi]``, by bisection.

    Kept local so the package has no runtime dependencies.
    """
    flo, fhi = f(lo), f(hi)
    if flo * fhi > 0:
        raise ValueError("root is not bracketed")
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        fmid = f(mid)
        if fmid == 0 or (hi - lo) < tol * max(1.0, abs(mid)):
            return mid
        if flo * fmid < 0:
            hi, fhi = mid, fmid
        else:
            lo, flo = mid, fmid
    return 0.5 * (lo + hi)


# --------------------------------------------------------------------------
# Landau-Levich
# --------------------------------------------------------------------------


def landau_levich_thickness(
    fluid: Fluid,
    speed: float,
    meniscus_radius: Optional[float] = None,
    mode: str = "confined",
) -> float:
    """Wet film thickness dragged out of a meniscus, SI m.

    Confined meniscus (``mode="confined"``), the case for a blade or a slot-die
    downstream meniscus of radius R::

        h = 1.34 R Ca^(2/3)

    Free meniscus (``mode="free"``), the original dip-coating result, where the
    capillary length l_c = sqrt(sigma / rho g) sets the scale::

        h = 0.94 l_c Ca^(2/3)

    Validity: Ca << 1 and negligible inertia. The 2/3 scaling is well confirmed
    in meniscus-guided coating of solution-processed films; the prefactor is
    sensitive to the meniscus radius, which is worth measuring rather than
    assuming.

    Args:
        fluid: The ink.
        speed: Substrate speed, SI m/s.
        meniscus_radius: Radius of the depositing meniscus, SI m. Required for
            ``mode="confined"``, ignored for ``mode="free"``.
        mode: ``"confined"`` or ``"free"``.
    """
    if speed < 0:
        raise ValueError("speed must be non-negative")
    ca = capillary_number(fluid.viscosity, speed, fluid.surface_tension)
    if mode == "confined":
        if meniscus_radius is None or meniscus_radius <= 0:
            raise ValueError("meniscus_radius is required and must be positive")
        return LANDAU_LEVICH_CONFINED * meniscus_radius * ca ** (2.0 / 3.0)
    if mode == "free":
        return LANDAU_LEVICH_FREE * fluid.capillary_length * ca ** (2.0 / 3.0)
    raise ValueError("mode must be 'confined' or 'free'")


landau_levich_thickness.references = ("landau1942", "ruschak1976", "leberre2009")


# --------------------------------------------------------------------------
# Slot die: low-flow limit and the vacuum window
# --------------------------------------------------------------------------


def low_flow_limit(fluid: Fluid, geometry: SlotDieGeometry, speed: float) -> float:
    """Minimum wet thickness the bead can sustain, SI m.

    The downstream meniscus obeys the Landau-Levich boundary condition
    h = 1.34 R Ca^(2/3), so a thinner film means a more curved meniscus. A
    meniscus pinned at the downstream lip corner and tangent to the substrate
    cannot have a radius smaller than half the downstream gap. Substituting
    R_min = H_down / 2 gives the low-flow limit::

        h_min = 1.34 (H_down / 2) Ca^(2/3) = 0.67 H_down Ca^(2/3)

    Below this the downstream meniscus recedes into the gap, air fingers invade
    the bead, and the coating breaks up. The limit is set by the downstream
    meniscus alone, so applying more vacuum does not move it.

    Validity: Ca <~ 1 and Re <~ 1. Above that, experiment departs from the
    viscocapillary model: Chang et al. (2007) report a plateau in h_min / H at
    moderate Ca, and Carvalho and Kheshgi (2000) report h_min falling again at
    high Ca and Re. :mod:`pvcoat.validity` raises those as warnings.
    """
    return landau_levich_thickness(
        fluid, speed, meniscus_radius=geometry.gap_downstream / 2.0, mode="confined"
    )


low_flow_limit.references = ("ruschak1976", "higgins1980", "carvalho2000", "ding2016")


def _bead_pressure_terms(
    fluid: Fluid, geometry: SlotDieGeometry, speed: float, wet: float
) -> Tuple[float, float, float]:
    """(capillary term downstream, maximum upstream capillary term, viscous term), SI Pa."""
    if wet <= 0:
        raise ValueError("wet thickness must be positive")
    mu, sigma = fluid.viscosity, fluid.surface_tension
    ca = capillary_number(mu, speed, sigma)
    h_up, h_down = geometry.gap_upstream, geometry.gap_downstream

    # Downstream meniscus: sigma / R_down with R_down set by the Landau-Levich
    # boundary condition, R_down = h_wet / (1.34 Ca^(2/3)).
    capillary_down = LANDAU_LEVICH_CONFINED * sigma * ca ** (2.0 / 3.0) / wet

    # Upstream meniscus pinned at the upstream lip corner: the tightest arc that
    # spans the gap has radius H_up / 2, so the capillary term is bounded by
    # 2 sigma / H_up in either direction.
    capillary_up_max = 2.0 * sigma / h_up

    # Lubrication pressure drop under the lips. Upstream of the slot the net
    # flow is zero, so dp/dx = 6 mu U / H_up^2. Downstream it carries q = h U,
    # so dp/dx = (6 mu U / H_down^2)(1 - 2 h / H_down).
    viscous = 6.0 * mu * speed * geometry.lip_length_upstream / h_up**2
    viscous += (
        6.0
        * mu
        * speed
        * geometry.lip_length_downstream
        / h_down**2
        * (1.0 - 2.0 * wet / h_down)
    )
    return capillary_down, capillary_up_max, viscous


def vacuum_window(
    fluid: Fluid, geometry: SlotDieGeometry, speed: float, wet: float
) -> Tuple[float, float]:
    """Range of applied vacuum that keeps the bead operable, SI Pa.

    Returns ``(dP_min, dP_max)`` where dP = P_atmosphere - P_vacuum_box, so a
    positive number is a suction and a negative dP_min means the bead is
    operable with no vacuum at all.

    The bead pressure balance sums the capillary jump at each meniscus and the
    lubrication pressure drop under the lips::

        dP = sigma/R_down - sigma/R_up + 6 mu U L_up / H_up^2
             + (6 mu U L_down / H_down^2)(1 - 2 h / H_down)

    with sigma/R_down fixed by the Landau-Levich boundary condition and
    sigma/R_up free to range over +/- 2 sigma / H_up as the upstream meniscus
    swings about its pinning corner. Those bounds on the upstream term give the
    two ends of the window. With both lip lengths zero the viscous terms vanish
    and this reduces to Ruschak's capillary model; with them set it is the
    viscocapillary model of Higgins and Scriven.

    Validity: Ca <~ 1, Re <~ 1, Newtonian ink, two-dimensional steady bead.
    """
    capillary_down, capillary_up_max, viscous = _bead_pressure_terms(
        fluid, geometry, speed, wet
    )
    lower = capillary_down - capillary_up_max + viscous
    upper = capillary_down + capillary_up_max + viscous
    return lower, upper


vacuum_window.references = ("ruschak1976", "higgins1980", "ding2016")


def required_vacuum(
    fluid: Fluid, geometry: SlotDieGeometry, speed: float, wet: float
) -> float:
    """Smallest vacuum that keeps the bead operable, SI Pa, clipped at zero.

    Convenience wrapper: the lower bound of :func:`vacuum_window`, reported as
    zero when the bead needs no suction.
    """
    lower, _ = vacuum_window(fluid, geometry, speed, wet)
    return max(0.0, lower)


def minimum_thickness_no_vacuum(
    fluid: Fluid, geometry: SlotDieGeometry, speed: float
) -> float:
    """Thinnest wet film coatable with no vacuum box, SI m.

    Solves dP_min(h) = 0 for h. The left-hand side falls monotonically with h,
    because both the downstream capillary term and the adverse viscous gradient
    weaken as the film thickens, so the root is unique. Ding et al. (2016) call
    this t_0 and distinguish it from the low-flow limit t_min: t_0 is set by how
    far the upstream meniscus can swing, t_min by the downstream meniscus.
    Always t_0 >= t_min.

    In the capillary limit (zero lip lengths, equal gaps and surface tensions)
    the root reduces to h_0 = 0.67 H_up Ca^(2/3), the same expression as the
    low-flow limit evaluated on the upstream gap.
    """

    def objective(h: float) -> float:
        return vacuum_window(fluid, geometry, speed, h)[0]

    if speed <= 0:
        raise ValueError("speed must be positive")
    lo = 1e-12
    hi = max(geometry.gap_downstream, geometry.gap_upstream)
    for _ in range(60):
        if objective(hi) < 0:
            break
        hi *= 2.0
    else:  # pragma: no cover - unreachable for physical inputs
        raise ValueError("no zero-vacuum solution found; check the geometry")
    return _bisect(objective, lo, hi)


minimum_thickness_no_vacuum.references = ("ruschak1976", "higgins1980", "ding2016")


# --------------------------------------------------------------------------
# Air entrainment (dynamic wetting failure)
# --------------------------------------------------------------------------


def air_entrainment_speed(
    fluid: Fluid, model: str = "gutoff_kendrick", critical_capillary_number: float = 1.0
) -> float:
    """Substrate speed at which the dynamic contact line fails, SI m/s.

    Above this speed the wetting line breaks into a sawtooth and entrains air,
    which dries into pinholes and craters. It is the upper speed bound of every
    coating window, slot-die and blade alike, because it is a property of the
    contact line rather than of the head.

    Two models:

    ``"gutoff_kendrick"``
        The dimensional correlation of Gutoff and Kendrick (1982),
        U_ae = 6.9 mu^-0.67 with mu in mPa s and U_ae in m/s. Viscosity is the
        dominant variable and surface tension a secondary one, which is why the
        correlation carries no sigma. Newtonian liquids and smooth substrates.
        For polymer solutions, Cohu and Benkreira report that the solvent
        viscosity predicts the failure speed better than the solution viscosity.

    ``"critical_capillary_number"``
        U_ae = Ca_crit sigma / mu, for when a critical capillary number has been
        measured on the actual ink and substrate. Pass it as
        ``critical_capillary_number``; the default of 1.0 is an order-of-
        magnitude placeholder, not a measurement.

    The two models disagree, often by a factor of a few, because air entrainment
    depends on substrate roughness, ambient pressure and contact-line chemistry
    that neither captures. Treat either as a bound to be confirmed on the line.
    """
    if model == "gutoff_kendrick":
        viscosity_mpas = fluid.viscosity * 1e3
        return AIR_ENTRAINMENT_PREFACTOR * viscosity_mpas**AIR_ENTRAINMENT_EXPONENT
    if model == "critical_capillary_number":
        if critical_capillary_number <= 0:
            raise ValueError("critical_capillary_number must be positive")
        return critical_capillary_number * fluid.surface_tension / fluid.viscosity
    raise ValueError("model must be 'gutoff_kendrick' or 'critical_capillary_number'")


air_entrainment_speed.references = ("gutoff1982",)


# --------------------------------------------------------------------------
# Blade coating: the evaporation regime and the crossover
# --------------------------------------------------------------------------


def evaporation_regime_dry_thickness(fluid: Fluid, speed: float) -> float:
    """Dry film thickness in the evaporation regime, SI m.

    At low speed the ink dries at the meniscus as fast as it is dragged out, so
    the solid deposits directly and mass conservation gives::

        h_dry = c E / (rho_film U)

    with c the solids mass concentration, E the solvent volume leaving the
    meniscus per unit blade length per second (``Fluid.evaporation_flux``), and
    U the coating speed. Thickness falls as 1/U, the signature of the regime.

    E is an apparatus property: it depends on the blade slit width, the
    substrate temperature, the gas flow over the meniscus and the solvent. It
    has to be measured on the coater, by fitting a thickness-versus-speed sweep
    in the low-speed branch. It is not a material constant.
    """
    if fluid.evaporation_flux is None:
        raise ValueError(
            "Fluid.evaporation_flux is required for the evaporation regime; "
            "measure it from a low-speed thickness sweep"
        )
    if speed <= 0:
        raise ValueError("speed must be positive")
    return (
        fluid.solids_concentration
        * fluid.evaporation_flux
        / (fluid.film_density * speed)
    )


evaporation_regime_dry_thickness.references = ("leberre2009", "huang2024")


def regime_crossover_speed(fluid: Fluid, meniscus_radius: float) -> float:
    """Speed at which the evaporation and Landau-Levich branches cross, SI m/s.

    Setting the two dry thicknesses equal, the solids fraction cancels from both
    sides and the crossover depends only on the evaporation flux, the meniscus
    radius and the ink's viscosity and surface tension::

        U* = [ E sigma^(2/3) / (1.34 R mu^(2/3)) ]^(3/5)

    U* is where the coated film is thinnest. Coating there is attractive for
    thin layers and unattractive for reproducibility, since dh/dU passes through
    zero and any speed error shows up as a thickness error only at second order,
    while the film morphology on either side of the crossover is different.
    """
    if fluid.evaporation_flux is None:
        raise ValueError("Fluid.evaporation_flux is required for the crossover speed")
    if meniscus_radius <= 0:
        raise ValueError("meniscus_radius must be positive")
    numerator = fluid.evaporation_flux * fluid.surface_tension ** (2.0 / 3.0)
    denominator = LANDAU_LEVICH_CONFINED * meniscus_radius * fluid.viscosity ** (2.0 / 3.0)
    return (numerator / denominator) ** (3.0 / 5.0)


regime_crossover_speed.references = ("leberre2009", "huang2024")


def blade_dry_thickness(fluid: Fluid, geometry: BladeGeometry, speed: float) -> Tuple[float, str]:
    """Dry thickness and the governing regime for a blade at ``speed``.

    Returns ``(h_dry, regime)`` where regime is ``"evaporation"`` or
    ``"landau_levich"``. Below the crossover the evaporation branch governs,
    above it the Landau-Levich branch does; the model takes the larger of the
    two, since the deposited film is whichever mechanism supplies more solid.
    """
    radius = geometry.effective_meniscus_radius
    wet = landau_levich_thickness(fluid, speed, meniscus_radius=radius, mode="confined")
    ll_dry = wet * fluid.solids_volume_fraction
    if fluid.evaporation_flux is None:
        return ll_dry, "landau_levich"
    evaporation_dry = evaporation_regime_dry_thickness(fluid, speed)
    if evaporation_dry >= ll_dry:
        return evaporation_dry, "evaporation"
    return ll_dry, "landau_levich"


blade_dry_thickness.references = ("landau1942", "leberre2009", "huang2024")
