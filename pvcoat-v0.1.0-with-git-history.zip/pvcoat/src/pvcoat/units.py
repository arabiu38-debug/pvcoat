"""Units.

pvcoat computes in SI throughout: metres, seconds, kilograms, pascals.
Coating practice does not use SI, so this module converts. Every public
function elsewhere in the package documents the SI unit it expects, and
:func:`parse_quantity` turns the strings people actually type into those units.

    >>> parse_quantity("3 cP", "viscosity")
    0.003
    >>> parse_quantity("100 um", "length")
    0.0001
"""

from __future__ import annotations

import re
from typing import Dict

#: Multiplicative factors to SI, grouped by physical dimension.
FACTORS: Dict[str, Dict[str, float]] = {
    "length": {
        "m": 1.0,
        "cm": 1e-2,
        "mm": 1e-3,
        "um": 1e-6,
        "µm": 1e-6,
        "micron": 1e-6,
        "microns": 1e-6,
        "nm": 1e-9,
        "in": 2.54e-2,
        "mil": 2.54e-5,
    },
    "velocity": {
        "m/s": 1.0,
        "cm/s": 1e-2,
        "mm/s": 1e-3,
        "um/s": 1e-6,
        "µm/s": 1e-6,
        "m/min": 1.0 / 60.0,
        "cm/min": 1e-2 / 60.0,
        "mm/min": 1e-3 / 60.0,
        "m/h": 1.0 / 3600.0,
    },
    "viscosity": {
        "pa.s": 1.0,
        "pas": 1.0,
        "pa*s": 1.0,
        "pa s": 1.0,
        "mpa.s": 1e-3,
        "mpas": 1e-3,
        "mpa s": 1e-3,
        "cp": 1e-3,
        "p": 1e-1,
        "poise": 1e-1,
    },
    "surface_tension": {
        "n/m": 1.0,
        "mn/m": 1e-3,
        "dyn/cm": 1e-3,
        "dyne/cm": 1e-3,
        "mj/m2": 1e-3,
        "mj/m^2": 1e-3,
    },
    "density": {
        "kg/m3": 1.0,
        "kg/m^3": 1.0,
        "g/cm3": 1e3,
        "g/cm^3": 1e3,
        "g/ml": 1e3,
        "g/l": 1.0,
        "mg/ml": 1.0,
    },
    "concentration": {
        "kg/m3": 1.0,
        "kg/m^3": 1.0,
        "g/l": 1.0,
        "mg/ml": 1.0,
        "g/ml": 1e3,
        "g/cm3": 1e3,
        "g/cm^3": 1e3,
    },
    "flow": {
        "m3/s": 1.0,
        "m^3/s": 1.0,
        "ml/min": 1e-6 / 60.0,
        "ml/s": 1e-6,
        "ul/min": 1e-9 / 60.0,
        "µl/min": 1e-9 / 60.0,
        "l/min": 1e-3 / 60.0,
        "cm3/s": 1e-6,
        "mm3/s": 1e-9,
    },
    "pressure": {
        "pa": 1.0,
        "kpa": 1e3,
        "mbar": 1e2,
        "bar": 1e5,
        "mmh2o": 9.80665,
        "mmhg": 133.322,
        "torr": 133.322,
        "inh2o": 249.0889,
        "psi": 6894.757,
    },
    "evaporation_flux": {
        # Volume of solvent leaving the meniscus per unit blade length per second.
        "m2/s": 1.0,
        "m^2/s": 1.0,
        "mm2/s": 1e-6,
        "um2/s": 1e-12,
        "cm2/s": 1e-4,
    },
}

_NUMBER = re.compile(
    r"^\s*([-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)\s*(.*?)\s*$"
)


class UnitError(ValueError):
    """Raised when a quantity string cannot be interpreted."""


def parse_quantity(value, dimension: str) -> float:
    """Convert ``value`` to SI for the given physical ``dimension``.

    A bare number is assumed to be in SI already, so ``parse_quantity(0.003,
    "viscosity")`` returns ``0.003`` unchanged. A string must carry a unit that
    appears in :data:`FACTORS` for that dimension.

    Raises:
        UnitError: if the dimension is unknown, the string is unparseable, or the
            unit is not one of the accepted units for that dimension.
    """
    if dimension not in FACTORS:
        raise UnitError(f"unknown dimension {dimension!r}")
    if isinstance(value, (int, float)):
        return float(value)
    if not isinstance(value, str):
        raise UnitError(f"cannot interpret {value!r} as a {dimension}")

    match = _NUMBER.match(value)
    if match is None:
        raise UnitError(f"cannot read a number from {value!r}")
    number, unit = match.groups()
    unit = unit.strip().lower().replace(" ", "") or None
    if unit is None:
        return float(number)

    table = FACTORS[dimension]
    normalised = {k.replace(" ", ""): v for k, v in table.items()}
    if unit not in normalised:
        accepted = ", ".join(sorted(table))
        raise UnitError(f"unit {unit!r} is not a {dimension} unit; accepted: {accepted}")
    return float(number) * normalised[unit]


def mass_concentration_from_molarity(molarity_mol_per_l: float, molar_mass_g_per_mol: float) -> float:
    """Mass concentration in kg/m3 from a molar concentration and a molar mass.

    Perovskite inks are specified in molarity, so this is the usual entry point:
    a 1.4 M FAPbI3 ink with M_w = 632.6 g/mol is 885.6 kg/m3 of solids.
    """
    if molarity_mol_per_l < 0 or molar_mass_g_per_mol <= 0:
        raise ValueError("molarity must be non-negative and molar mass positive")
    return molarity_mol_per_l * molar_mass_g_per_mol  # mol/L * g/mol = g/L = kg/m3


def to_um(metres: float) -> float:
    """Metres to micrometres, for display."""
    return metres * 1e6


def to_nm(metres: float) -> float:
    """Metres to nanometres, for display."""
    return metres * 1e9


def to_mm_per_s(metres_per_second: float) -> float:
    """Metres per second to millimetres per second, for display."""
    return metres_per_second * 1e3


def to_mbar(pascals: float) -> float:
    """Pascals to millibar, the unit vacuum boxes are usually set in."""
    return pascals / 100.0
