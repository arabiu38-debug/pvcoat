"""Blade coating: evaluate a process point, or sweep the thickness-speed curve."""

from __future__ import annotations

from typing import List, Optional, Sequence

from .dimensionless import capillary_number
from .fluids import Fluid
from .geometry import BladeGeometry
from .limits import (
    air_entrainment_speed,
    blade_dry_thickness,
    evaporation_regime_dry_thickness,
    landau_levich_thickness,
    regime_crossover_speed,
)
from .report import BladeResult, Window
from .units import parse_quantity
from .validity import check_landau_levich


def evaluate(
    fluid: Fluid,
    geometry: BladeGeometry,
    speed: float,
    air_entrainment_model: str = "gutoff_kendrick",
    critical_capillary_number: float = 1.0,
) -> BladeResult:
    """Evaluate one blade-coating process point.

    Blade coating is self-metered, so the answer runs the other way from
    slot-die: the speed sets the thickness rather than the thickness setting the
    speed. The result reports which of the two regimes governs at this speed,
    where the crossover sits, and how much room is left before the contact line
    entrains air.
    """
    speed = parse_quantity(speed, "velocity")
    if speed <= 0:
        raise ValueError("speed must be positive")
    radius = geometry.effective_meniscus_radius
    ca = capillary_number(fluid.viscosity, speed, fluid.surface_tension)
    wet = landau_levich_thickness(fluid, speed, meniscus_radius=radius, mode="confined")

    crossover: Optional[float] = None
    thinnest: Optional[float] = None
    if fluid.evaporation_flux is not None:
        crossover = regime_crossover_speed(fluid, radius)
        thinnest = evaporation_regime_dry_thickness(fluid, crossover)

    if fluid.solids_concentration is None or fluid.film_density is None:
        raise ValueError(
            "blade evaluation needs solids_concentration and film_density on the "
            "Fluid, since the deposited film is reported dry"
        )
    dry, regime = blade_dry_thickness(fluid, geometry, speed)

    result = BladeResult(
        speed=speed,
        wet_thickness=wet,
        dry_thickness=dry,
        regime=regime,
        capillary_number=ca,
        crossover_speed=crossover,
        minimum_dry_thickness=thinnest,
        air_entrainment_speed=air_entrainment_speed(
            fluid, air_entrainment_model, critical_capillary_number
        ),
        validity=check_landau_levich(ca),
        references=["landau1942", "leberre2009", "gutoff1982", "huang2024"],
    )
    if fluid.evaporation_flux is None:
        result.notes.append(
            "No evaporation_flux on the Fluid, so only the Landau-Levich branch "
            "was evaluated. Measure the flux from a low-speed thickness sweep to "
            "get the evaporation branch and the crossover."
        )
    elif crossover is not None:
        if speed < crossover:
            result.notes.append(
                "Below the crossover: thickness falls as 1/U, so a speed error "
                "translates directly into a thickness error."
            )
        else:
            result.notes.append(
                "Above the crossover: thickness rises as U^(2/3), and the wet "
                "film dries after deposition rather than at the meniscus."
            )
    return result


def thickness_curve(
    fluid: Fluid, geometry: BladeGeometry, speeds: Sequence[float]
) -> List[dict]:
    """Dry thickness against speed, with both branches, for plotting.

    Returns one row per speed carrying the evaporation branch, the
    Landau-Levich branch, and the governing value. The evaporation columns are
    ``None`` when the fluid has no evaporation flux.
    """
    radius = geometry.effective_meniscus_radius
    rows = []
    for speed in speeds:
        wet = landau_levich_thickness(fluid, speed, meniscus_radius=radius)
        ll_dry = wet * fluid.solids_volume_fraction
        evaporation = (
            evaporation_regime_dry_thickness(fluid, speed)
            if fluid.evaporation_flux is not None
            else None
        )
        governing, regime = blade_dry_thickness(fluid, geometry, speed)
        rows.append(
            {
                "speed_m_s": speed,
                "capillary_number": capillary_number(
                    fluid.viscosity, speed, fluid.surface_tension
                ),
                "wet_thickness_landau_levich_m": wet,
                "dry_thickness_landau_levich_m": ll_dry,
                "dry_thickness_evaporation_m": evaporation,
                "dry_thickness_governing_m": governing,
                "regime": regime,
            }
        )
    return rows


def window(
    fluid: Fluid,
    geometry: BladeGeometry,
    speeds: Sequence[float],
    **kwargs,
) -> Window:
    """Label every speed in a sweep operable, marginal or not, for a blade."""
    points = []
    for speed in speeds:
        result = evaluate(fluid, geometry, speed, **kwargs)
        points.append(
            {
                "speed_m_s": speed,
                "capillary_number": result.capillary_number,
                "wet_thickness_m": result.wet_thickness,
                "dry_thickness_m": result.dry_thickness,
                "regime": result.regime,
                "speed_margin": result.speed_margin,
                "verdict": result.verdict,
                "warning_codes": ";".join(w.code for w in result.validity),
            }
        )
    return Window(points=points, axes={"speed_m_s": list(speeds)}, kind="blade")
