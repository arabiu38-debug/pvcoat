"""Dimensionless groups used by the operability models.

The definitions matter, because the validity ranges quoted in the coating
literature are stated in terms of these particular forms. Where an alternative
definition is in circulation it is named in the docstring.
"""

from __future__ import annotations

GRAVITY = 9.80665


def capillary_number(viscosity: float, speed: float, surface_tension: float) -> float:
    """Ca = mu U / sigma, the ratio of viscous to capillary force.

    This is the form used throughout the slot-coating literature, with U the
    substrate speed and sigma the liquid-air surface tension. The viscocapillary
    operability models are derived for Ca << 1 and are reported to hold to about
    Ca ~ 1 (Carvalho and Kheshgi 2000).

    Args:
        viscosity: SI Pa s.
        speed: Substrate speed, SI m/s.
        surface_tension: SI N/m.
    """
    if surface_tension <= 0:
        raise ValueError("surface_tension must be positive")
    return viscosity * speed / surface_tension


def reynolds_number(density: float, flow_per_width: float, viscosity: float) -> float:
    """Re = rho q / mu, with q the flow rate per unit width, SI m2/s.

    This is the convention of Carvalho and Kheshgi (2000), not the gap-based
    Reynolds number; see :func:`gap_reynolds_number` for that one. The
    viscocapillary models assume Re << 1, and inertia is reported to matter
    above Re of order 10 (Chang et al. 2007).
    """
    if viscosity <= 0:
        raise ValueError("viscosity must be positive")
    return density * flow_per_width / viscosity


def gap_reynolds_number(density: float, speed: float, gap: float, viscosity: float) -> float:
    """Re_H = rho U H / mu, the gap-based Reynolds number."""
    if viscosity <= 0:
        raise ValueError("viscosity must be positive")
    return density * speed * gap / viscosity


def stokes_number(density: float, viscosity: float, speed: float) -> float:
    """St = rho g h^2 / (mu U) evaluated at h = capillary length; gravity vs viscous drag.

    Reported for context only: gravity drainage is negligible for the film
    thicknesses this package targets, and none of the limits use it.
    """
    raise NotImplementedError(
        "gravity drainage is out of scope in v0.1; see docs/NEXT_STEPS.md"
    )


def gap_to_thickness_ratio(gap: float, wet_thickness: float) -> float:
    """H / t, the group the low-flow limit is usually plotted against."""
    if wet_thickness <= 0:
        raise ValueError("wet_thickness must be positive")
    return gap / wet_thickness
