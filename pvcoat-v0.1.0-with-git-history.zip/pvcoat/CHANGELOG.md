# Changelog

Format follows Keep a Changelog; versioning is semantic.

## [0.1.0] - 2026-09-02

First public version. Implements the published models named in the build spec,
with tests and documentation, and no experimental validation.

### Added

- `Fluid` and geometry objects (`SlotDieGeometry`, `BladeGeometry`) accepting
  either SI numbers or unit strings.
- Metering: wet thickness from flow rate, dry thickness from solids loading, and
  the inverses (pump setting for a target dry thickness).
- Slot-die limits: the low-flow limit from the Landau-Levich boundary condition,
  the coating-bead vacuum window in both capillary and viscocapillary form, and
  the zero-vacuum minimum thickness by root-finding.
- Air-entrainment speed, from the Gutoff-Kendrick correlation or a measured
  critical capillary number.
- Blade coating: Landau-Levich thickness for confined and free menisci, the
  evaporation regime, the regime crossover and the governing branch.
- `pvcoat.validity`, which attaches explicit warnings to results computed outside
  the range their model was derived for.
- Window sweeps for both heads, with CSV export.
- Command-line interface: `slot-die`, `blade`, `window`, `references`.
- A bibliography every model function points into.
- Worked perovskite example producing a stats file, a QA report and two figures,
  with the README's numbers interpolated from the stats file.

### Known issues

- No validation against coating experiments. pvcoat reproduces published
  equations and checks itself analytically; it has not been tested against a
  coating trial. See LIMITATIONS.md item 13, and NEXT_STEPS.md, where closing
  this is the first item of v0.2.
- Newtonian inks only, and only three of the failure modes that bound a real
  window are implemented. See LIMITATIONS.md items 1 and 2.
- The blade evaporation flux is an apparatus constant that every user must
  measure on their own coater. See LIMITATIONS.md item 8.
