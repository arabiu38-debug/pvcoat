import math

import pytest

from pvcoat import Fluid
from pvcoat.units import (
    UnitError,
    mass_concentration_from_molarity,
    parse_quantity,
)


def test_bare_number_is_si():
    assert parse_quantity(0.003, "viscosity") == 0.003
    assert parse_quantity("0.003", "viscosity") == 0.003


@pytest.mark.parametrize(
    "text,dimension,expected",
    [
        ("3 cP", "viscosity", 3e-3),
        ("3 mPa s", "viscosity", 3e-3),
        ("1 poise", "viscosity", 0.1),
        ("100 um", "length", 1e-4),
        ("2 mil", "length", 5.08e-5),
        ("30 mN/m", "surface_tension", 0.030),
        ("30 dyn/cm", "surface_tension", 0.030),
        ("1.45 g/cm3", "density", 1450.0),
        ("0.5 mL/min", "flow", 0.5e-6 / 60.0),
        ("10 mm/s", "velocity", 0.01),
        ("6 m/min", "velocity", 0.1),
        ("20 mbar", "pressure", 2000.0),
        ("1 torr", "pressure", 133.322),
    ],
)
def test_unit_conversions(text, dimension, expected):
    assert parse_quantity(text, dimension) == pytest.approx(expected, rel=1e-12)


def test_equivalent_spellings_agree():
    assert parse_quantity("3cP", "viscosity") == parse_quantity("3 cP", "viscosity")
    assert parse_quantity("30 mN/m", "surface_tension") == parse_quantity(
        "30 dyne/cm", "surface_tension"
    )


def test_unknown_unit_is_rejected_with_the_alternatives():
    with pytest.raises(UnitError) as excinfo:
        parse_quantity("3 furlongs", "length")
    assert "furlongs" in str(excinfo.value)
    assert "um" in str(excinfo.value)


def test_unknown_dimension_is_rejected():
    with pytest.raises(UnitError):
        parse_quantity("3 cP", "luminosity")


def test_molarity_to_mass_concentration():
    # 1.4 M FAPbI3, M_w = 632.6 g/mol -> 885.6 g/L -> 885.6 kg/m3
    assert mass_concentration_from_molarity(1.4, 632.6) == pytest.approx(885.64)


def test_fluid_accepts_strings_and_numbers_identically():
    a = Fluid(viscosity="3 cP", surface_tension="30 mN/m", density="1.45 g/cm3")
    b = Fluid(viscosity=0.003, surface_tension=0.030, density=1450.0)
    assert (a.viscosity, a.surface_tension, a.density) == (
        b.viscosity,
        b.surface_tension,
        b.density,
    )


def test_solids_volume_fraction():
    ink = Fluid(
        viscosity="3 cP",
        surface_tension="30 mN/m",
        density="1.45 g/cm3",
        solids_concentration="886 kg/m3",
        film_density="4.1 g/cm3",
    )
    assert ink.solids_volume_fraction == pytest.approx(886.0 / 4100.0)


def test_dry_thickness_needs_both_solids_numbers():
    ink = Fluid(viscosity="3 cP", surface_tension="30 mN/m", density="1.45 g/cm3")
    with pytest.raises(ValueError):
        _ = ink.solids_volume_fraction


def test_capillary_length_of_water_is_about_2_7_mm():
    water = Fluid(viscosity="1 cP", surface_tension="72 mN/m", density="1 g/cm3")
    assert water.capillary_length == pytest.approx(2.71e-3, rel=0.01)


def test_negative_properties_are_rejected():
    with pytest.raises(ValueError):
        Fluid(viscosity=-1, surface_tension="30 mN/m", density="1 g/cm3")


def test_from_molarity_round_trip():
    ink = Fluid.from_molarity(
        viscosity="3 cP",
        surface_tension="30 mN/m",
        density="1.45 g/cm3",
        molarity_mol_per_l=1.4,
        molar_mass_g_per_mol=632.6,
        film_density="4.1 g/cm3",
    )
    assert ink.solids_concentration == pytest.approx(885.64)
    assert ink.solids_volume_fraction == pytest.approx(885.64 / 4100.0)


def test_representative_shear_rate():
    ink = Fluid(viscosity="3 cP", surface_tension="30 mN/m", density="1.45 g/cm3")
    assert ink.representative_shear_rate(0.01, 100e-6) == pytest.approx(100.0)
