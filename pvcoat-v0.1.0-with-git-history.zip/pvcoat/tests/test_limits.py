"""Model tests.

Each test states the property it protects. Where a closed-form answer exists,
the test checks against the closed form rather than a recorded output, so a
refactor that changes the physics fails loudly.
"""

import math

import pytest

from pvcoat import Fluid, SlotDieGeometry
from pvcoat.dimensionless import capillary_number
from pvcoat.limits import (
    LANDAU_LEVICH_CONFINED,
    LANDAU_LEVICH_FREE,
    air_entrainment_speed,
    blade_dry_thickness,
    evaporation_regime_dry_thickness,
    landau_levich_thickness,
    low_flow_limit,
    minimum_thickness_no_vacuum,
    regime_crossover_speed,
    required_vacuum,
    vacuum_window,
)
from pvcoat.geometry import BladeGeometry


@pytest.fixture
def ink():
    """A perovskite-like precursor ink: DMF/DMSO, moderate solids loading."""
    return Fluid(
        viscosity="3 cP",
        surface_tension="30 mN/m",
        density="1.45 g/cm3",
        solids_concentration="886 kg/m3",
        film_density="4.1 g/cm3",
        name="1.4 M FAPbI3 in DMF/DMSO",
    )


@pytest.fixture
def die():
    return SlotDieGeometry(
        gap_downstream="100 um",
        gap_upstream="100 um",
        coating_width="50 mm",
        name="lab slot die",
    )


# ---------------------------------------------------------------- Landau-Levich


def test_landau_levich_matches_its_closed_form(ink):
    speed, radius = 0.01, 50e-6
    ca = capillary_number(ink.viscosity, speed, ink.surface_tension)
    expected = LANDAU_LEVICH_CONFINED * radius * ca ** (2 / 3)
    assert landau_levich_thickness(ink, speed, radius) == pytest.approx(expected)


def test_landau_levich_scales_as_speed_to_the_two_thirds(ink):
    thin = landau_levich_thickness(ink, 0.01, 50e-6)
    thick = landau_levich_thickness(ink, 0.08, 50e-6)
    assert thick / thin == pytest.approx(8 ** (2 / 3))


def test_free_meniscus_uses_the_capillary_length(ink):
    speed = 0.01
    ca = capillary_number(ink.viscosity, speed, ink.surface_tension)
    expected = LANDAU_LEVICH_FREE * ink.capillary_length * ca ** (2 / 3)
    assert landau_levich_thickness(ink, speed, mode="free") == pytest.approx(expected)


def test_confined_mode_requires_a_radius(ink):
    with pytest.raises(ValueError):
        landau_levich_thickness(ink, 0.01)


def test_unknown_mode_is_rejected(ink):
    with pytest.raises(ValueError):
        landau_levich_thickness(ink, 0.01, 50e-6, mode="magic")


# ---------------------------------------------------------------- low-flow limit


def test_low_flow_limit_is_landau_levich_on_half_the_downstream_gap(ink, die):
    speed = 0.01
    ca = capillary_number(ink.viscosity, speed, ink.surface_tension)
    expected = LANDAU_LEVICH_CONFINED * (die.gap_downstream / 2) * ca ** (2 / 3)
    assert low_flow_limit(ink, die, speed) == pytest.approx(expected)
    # the 0.67 H Ca^(2/3) form quoted in the literature
    assert low_flow_limit(ink, die, speed) == pytest.approx(
        0.67 * die.gap_downstream * ca ** (2 / 3)
    )


def test_low_flow_limit_is_proportional_to_the_gap(ink):
    narrow = SlotDieGeometry(gap_downstream="50 um", coating_width="50 mm")
    wide = SlotDieGeometry(gap_downstream="200 um", coating_width="50 mm")
    assert low_flow_limit(ink, wide, 0.01) == pytest.approx(
        4 * low_flow_limit(ink, narrow, 0.01)
    )


def test_low_flow_limit_rises_with_speed_in_the_viscocapillary_regime(ink, die):
    speeds = [0.002, 0.005, 0.01, 0.02]
    values = [low_flow_limit(ink, die, u) for u in speeds]
    assert values == sorted(values)


def test_low_flow_limit_ignores_the_upstream_gap(ink):
    a = SlotDieGeometry(gap_downstream="100 um", gap_upstream="80 um", coating_width="50 mm")
    b = SlotDieGeometry(gap_downstream="100 um", gap_upstream="300 um", coating_width="50 mm")
    assert low_flow_limit(ink, a, 0.01) == low_flow_limit(ink, b, 0.01)


# ---------------------------------------------------------------- vacuum window


def test_vacuum_window_width_is_set_by_the_upstream_meniscus(ink, die):
    lower, upper = vacuum_window(ink, die, 0.01, 20e-6)
    assert upper - lower == pytest.approx(4 * ink.surface_tension / die.gap_upstream)


def test_vacuum_demand_falls_as_the_film_thickens(ink, die):
    thin = vacuum_window(ink, die, 0.01, 5e-6)[0]
    thick = vacuum_window(ink, die, 0.01, 40e-6)[0]
    assert thin > thick


def test_required_vacuum_is_clipped_at_zero(ink, die):
    assert required_vacuum(ink, die, 0.01, 40e-6) == 0.0


def test_capillary_model_zero_vacuum_thickness_has_a_closed_form(ink, die):
    """With no lip lengths the viscous terms vanish and t_0 = 0.67 H_up Ca^(2/3)."""
    speed = 0.01
    ca = capillary_number(ink.viscosity, speed, ink.surface_tension)
    expected = LANDAU_LEVICH_CONFINED * (die.gap_upstream / 2) * ca ** (2 / 3)
    assert minimum_thickness_no_vacuum(ink, die, speed) == pytest.approx(
        expected, rel=1e-9
    )


def test_zero_vacuum_thickness_equals_the_low_flow_limit_for_a_parallel_capillary_die(
    ink, die
):
    speed = 0.01
    assert minimum_thickness_no_vacuum(ink, die, speed) == pytest.approx(
        low_flow_limit(ink, die, speed), rel=1e-9
    )


def test_the_zero_vacuum_root_actually_zeroes_the_window(ink):
    """The viscocapillary case has no closed form, so check the defining equation."""
    viscocapillary = SlotDieGeometry(
        gap_downstream="100 um",
        gap_upstream="120 um",
        lip_length_downstream="1 mm",
        lip_length_upstream="0.5 mm",
        coating_width="50 mm",
    )
    speed = 0.02
    root = minimum_thickness_no_vacuum(ink, viscocapillary, speed)
    lower, _ = vacuum_window(ink, viscocapillary, speed, root)
    assert lower == pytest.approx(0.0, abs=1e-6)


def test_a_wider_upstream_gap_lowers_the_zero_vacuum_thickness(ink):
    """A wider upstream gap means a flatter meniscus, so less thickness is needed."""
    narrow = SlotDieGeometry(gap_downstream="100 um", gap_upstream="60 um", coating_width="50 mm")
    wide = SlotDieGeometry(gap_downstream="100 um", gap_upstream="200 um", coating_width="50 mm")
    assert minimum_thickness_no_vacuum(ink, wide, 0.01) > minimum_thickness_no_vacuum(
        ink, narrow, 0.01
    )


# ---------------------------------------------------------------- air entrainment


def test_gutoff_kendrick_at_one_millipascal_second_is_the_prefactor(ink):
    water_like = Fluid(viscosity="1 cP", surface_tension="72 mN/m", density="1 g/cm3")
    assert air_entrainment_speed(water_like) == pytest.approx(6.9)


def test_gutoff_kendrick_falls_with_viscosity(ink):
    thin = Fluid(viscosity="1 cP", surface_tension="30 mN/m", density="1 g/cm3")
    thick = Fluid(viscosity="100 cP", surface_tension="30 mN/m", density="1 g/cm3")
    assert air_entrainment_speed(thick) < air_entrainment_speed(thin)
    assert air_entrainment_speed(thick) == pytest.approx(6.9 * 100 ** (-0.67))


def test_critical_capillary_number_model(ink):
    speed = air_entrainment_speed(
        ink, model="critical_capillary_number", critical_capillary_number=0.5
    )
    assert speed == pytest.approx(0.5 * ink.surface_tension / ink.viscosity)


def test_unknown_air_entrainment_model_is_rejected(ink):
    with pytest.raises(ValueError):
        air_entrainment_speed(ink, model="guesswork")


# ---------------------------------------------------------------- blade regimes


@pytest.fixture
def blade_ink(ink):
    return Fluid(
        viscosity=ink.viscosity,
        surface_tension=ink.surface_tension,
        density=ink.density,
        solids_concentration=ink.solids_concentration,
        film_density=ink.film_density,
        evaporation_flux="6e-9 m2/s",
        name=ink.name,
    )


def test_evaporation_regime_falls_as_one_over_speed(blade_ink):
    slow = evaporation_regime_dry_thickness(blade_ink, 0.001)
    fast = evaporation_regime_dry_thickness(blade_ink, 0.004)
    assert slow / fast == pytest.approx(4.0)


def test_evaporation_regime_needs_a_flux(ink):
    with pytest.raises(ValueError):
        evaporation_regime_dry_thickness(ink, 0.001)


def test_the_two_branches_are_equal_at_the_crossover(blade_ink):
    radius = 75e-6
    crossover = regime_crossover_speed(blade_ink, radius)
    evaporation = evaporation_regime_dry_thickness(blade_ink, crossover)
    landau_levich = (
        landau_levich_thickness(blade_ink, crossover, radius)
        * blade_ink.solids_volume_fraction
    )
    assert evaporation == pytest.approx(landau_levich, rel=1e-9)


def test_the_crossover_does_not_depend_on_solids_loading(blade_ink):
    dilute = Fluid(
        viscosity=blade_ink.viscosity,
        surface_tension=blade_ink.surface_tension,
        density=blade_ink.density,
        solids_concentration=blade_ink.solids_concentration / 3,
        film_density=blade_ink.film_density,
        evaporation_flux=blade_ink.evaporation_flux,
    )
    assert regime_crossover_speed(dilute, 75e-6) == pytest.approx(
        regime_crossover_speed(blade_ink, 75e-6)
    )


def test_the_governing_branch_switches_at_the_crossover(blade_ink):
    geometry = BladeGeometry(gap="150 um", coating_width="50 mm")
    crossover = regime_crossover_speed(blade_ink, geometry.effective_meniscus_radius)
    below, regime_below = blade_dry_thickness(blade_ink, geometry, crossover * 0.5)
    above, regime_above = blade_dry_thickness(blade_ink, geometry, crossover * 2.0)
    assert regime_below == "evaporation"
    assert regime_above == "landau_levich"
    at_crossover, _ = blade_dry_thickness(blade_ink, geometry, crossover)
    assert below > at_crossover
    assert above > at_crossover


def test_the_crossover_is_the_thinnest_film(blade_ink):
    geometry = BladeGeometry(gap="150 um", coating_width="50 mm")
    radius = geometry.effective_meniscus_radius
    crossover = regime_crossover_speed(blade_ink, radius)
    thinnest = blade_dry_thickness(blade_ink, geometry, crossover)[0]
    speeds = [crossover * f for f in (0.25, 0.5, 0.8, 1.25, 2.0, 4.0)]
    assert all(blade_dry_thickness(blade_ink, geometry, u)[0] >= thinnest for u in speeds)


def test_blade_falls_back_to_landau_levich_without_a_flux(ink):
    geometry = BladeGeometry(gap="150 um", coating_width="50 mm")
    value, regime = blade_dry_thickness(ink, geometry, 0.01)
    assert regime == "landau_levich"
    assert value > 0
