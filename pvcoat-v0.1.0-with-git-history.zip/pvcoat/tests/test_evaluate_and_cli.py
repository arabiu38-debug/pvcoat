import json

import pytest

from pvcoat import BladeGeometry, Fluid, SlotDieGeometry, blade, slotdie
from pvcoat.cli import main
from pvcoat.validity import (
    CA_VISCOCAPILLARY_MAX,
    check_landau_levich,
    check_viscocapillary,
)


@pytest.fixture
def ink():
    return Fluid.from_molarity(
        viscosity="3 cP",
        surface_tension="30 mN/m",
        density="1.45 g/cm3",
        molarity_mol_per_l=1.4,
        molar_mass_g_per_mol=632.6,
        film_density="4.1 g/cm3",
        evaporation_flux="1e-10 m2/s",
        name="1.4 M FAPbI3 in DMF/DMSO",
    )


@pytest.fixture
def die():
    return SlotDieGeometry(
        gap_downstream="100 um",
        gap_upstream="100 um",
        lip_length_downstream="1 mm",
        lip_length_upstream="1 mm",
        coating_width="50 mm",
    )


# ---------------------------------------------------------------- slot die


def test_flow_and_thickness_are_two_ways_to_say_the_same_thing(ink, die):
    by_thickness = slotdie.evaluate(ink, die, "10 mm/s", target_wet_thickness="12 um")
    by_flow = slotdie.evaluate(ink, die, "10 mm/s", flow_rate=by_thickness.flow_rate)
    assert by_flow.wet_thickness == pytest.approx(by_thickness.wet_thickness)
    assert by_flow.verdict == by_thickness.verdict


def test_evaluate_rejects_both_or_neither(ink, die):
    with pytest.raises(ValueError):
        slotdie.evaluate(ink, die, "10 mm/s")
    with pytest.raises(ValueError):
        slotdie.evaluate(ink, die, "10 mm/s", flow_rate=1e-8, target_wet_thickness=1e-5)


def test_dry_thickness_tracks_the_solids_fraction(ink, die):
    result = slotdie.evaluate(ink, die, "10 mm/s", target_wet_thickness="12 um")
    assert result.dry_thickness == pytest.approx(12e-6 * ink.solids_volume_fraction)


def test_a_film_below_the_low_flow_limit_is_not_operable(ink):
    """A wide gap at speed pushes the low-flow limit above a thin target film."""
    wide = SlotDieGeometry(gap_downstream="1 mm", coating_width="50 mm")
    result = slotdie.evaluate(ink, wide, "100 mm/s", target_wet_thickness="1 um")
    assert result.low_flow_margin < 1
    assert result.verdict == "not operable"


def test_flooding_is_an_error_not_a_warning(ink, die):
    result = slotdie.evaluate(ink, die, "10 mm/s", target_wet_thickness="150 um")
    assert any(w.code == "FLOODING" for w in result.validity)
    assert result.validity.has_error
    assert result.verdict == "not operable"


def test_speed_above_air_entrainment_is_not_operable(ink):
    die = SlotDieGeometry(gap_downstream="10 mm", coating_width="50 mm")
    result = slotdie.evaluate(
        ink,
        die,
        "10 m/s",
        target_wet_thickness="500 um",
        air_entrainment_model="critical_capillary_number",
        critical_capillary_number=0.001,
    )
    assert result.speed_margin < 1
    assert result.verdict == "not operable"


def test_capillary_model_is_flagged_in_the_notes(ink):
    no_lips = SlotDieGeometry(gap_downstream="100 um", coating_width="50 mm")
    result = slotdie.evaluate(ink, no_lips, "10 mm/s", target_wet_thickness="12 um")
    assert any("capillary model" in note for note in result.notes)


def test_result_serialises_to_json(ink, die):
    result = slotdie.evaluate(ink, die, "10 mm/s", target_wet_thickness="12 um")
    payload = json.dumps(result.to_dict())
    assert "verdict" in payload
    assert "low_flow_margin" in payload


def test_render_is_human_readable(ink, die):
    text = slotdie.evaluate(ink, die, "10 mm/s", target_wet_thickness="12 um").render()
    assert "low-flow limit" in text
    assert "verdict" in text


# ---------------------------------------------------------------- windows


def test_slot_die_window_covers_the_grid(ink, die):
    speeds = [0.005, 0.01, 0.02]
    thicknesses = [5e-6, 10e-6, 20e-6, 40e-6]
    window = slotdie.window(ink, die, speeds, thicknesses)
    assert len(window.points) == len(speeds) * len(thicknesses)
    assert set(p["verdict"] for p in window.points) <= {
        "operable",
        "marginal",
        "not operable",
    }


def test_window_csv_has_a_header_and_one_row_per_point(ink, die):
    window = slotdie.window(ink, die, [0.005, 0.01], [10e-6, 20e-6])
    lines = window.to_csv().strip().split("\n")
    assert len(lines) == 5
    assert lines[0].startswith("speed_m_s,wet_thickness_m")


def test_limit_curve_is_monotone_in_speed(ink, die):
    rows = slotdie.limit_curve(ink, die, [0.002, 0.005, 0.01, 0.05])
    values = [row["low_flow_limit_m"] for row in rows]
    assert values == sorted(values)


def test_blade_window_and_curve(ink):
    geometry = BladeGeometry(gap="150 um", coating_width="50 mm")
    speeds = [0.002, 0.005, 0.01, 0.02]
    rows = blade.thickness_curve(ink, geometry, speeds)
    assert len(rows) == 4
    assert all(row["dry_thickness_governing_m"] > 0 for row in rows)
    window = blade.window(ink, geometry, speeds)
    assert window.summary().startswith("blade window")


def test_blade_needs_solids_numbers(ink):
    bare = Fluid(viscosity="3 cP", surface_tension="30 mN/m", density="1.45 g/cm3")
    geometry = BladeGeometry(gap="150 um", coating_width="50 mm")
    with pytest.raises(ValueError):
        blade.evaluate(bare, geometry, "10 mm/s")


def test_blade_meniscus_radius_defaults_to_half_the_gap():
    geometry = BladeGeometry(gap="150 um", coating_width="50 mm")
    assert geometry.effective_meniscus_radius == pytest.approx(75e-6)
    explicit = BladeGeometry(gap="150 um", coating_width="50 mm", meniscus_radius="200 um")
    assert explicit.effective_meniscus_radius == pytest.approx(200e-6)


# ---------------------------------------------------------------- validity


def test_high_capillary_number_is_flagged():
    report = check_viscocapillary(capillary=5.0, reynolds=0.1)
    assert any(w.code == "CA_HIGH" for w in report)
    assert not report.ok
    assert not report.has_error


def test_clean_point_has_no_warnings():
    report = check_viscocapillary(capillary=0.01, reynolds=0.05, thickness_ratio=0.2)
    assert report.ok
    assert report.render() == "no validity concerns"


def test_landau_levich_validity_threshold():
    assert check_landau_levich(CA_VISCOCAPILLARY_MAX * 0.5).ok
    assert not check_landau_levich(CA_VISCOCAPILLARY_MAX * 2).ok


# ---------------------------------------------------------------- CLI


SLOT_ARGS = [
    "slot-die",
    "--viscosity", "3 cP",
    "--surface-tension", "30 mN/m",
    "--density", "1.45 g/cm3",
    "--molarity", "1.4",
    "--molar-mass", "632.6",
    "--film-density", "4.1 g/cm3",
    "--gap", "100 um",
    "--lip-downstream", "1 mm",
    "--lip-upstream", "1 mm",
    "--width", "50 mm",
    "--speed", "10 mm/s",
    "--wet-thickness", "12 um",
]


def test_cli_slot_die_prints_a_report(capsys):
    assert main(SLOT_ARGS) == 0
    out = capsys.readouterr().out
    assert "low-flow limit" in out
    assert "verdict" in out


def test_cli_slot_die_json(capsys):
    assert main(SLOT_ARGS + ["--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["verdict"] == "operable"
    assert payload["wet_thickness"] == pytest.approx(12e-6)


def test_cli_blade(capsys):
    code = main(
        [
            "blade",
            "--viscosity", "3 cP",
            "--surface-tension", "30 mN/m",
            "--density", "1.45 g/cm3",
            "--molarity", "1.4",
            "--molar-mass", "632.6",
            "--film-density", "4.1 g/cm3",
            "--evaporation-flux", "1e-10 m2/s",
            "--gap", "150 um",
            "--width", "50 mm",
            "--speed", "15 mm/s",
        ]
    )
    assert code == 0
    assert "governing regime" in capsys.readouterr().out


def test_cli_window_writes_csv(tmp_path, capsys):
    out = tmp_path / "window.csv"
    code = main(
        [
            "window",
            "--viscosity", "3 cP",
            "--surface-tension", "30 mN/m",
            "--density", "1.45 g/cm3",
            "--gap", "100 um",
            "--width", "50 mm",
            "--speed-range", "2 mm/s,20 mm/s,4",
            "--thickness-range", "2 um,20 um,4",
            "--out", str(out),
        ]
    )
    assert code == 0
    lines = out.read_text().strip().split("\n")
    assert len(lines) == 17
    assert "operable" in out.read_text()


def test_cli_window_requires_thickness_range_for_slot_die():
    with pytest.raises(SystemExit):
        main(
            [
                "window",
                "--viscosity", "3 cP",
                "--surface-tension", "30 mN/m",
                "--density", "1.45 g/cm3",
                "--gap", "100 um",
                "--width", "50 mm",
                "--speed-range", "2 mm/s,20 mm/s,4",
            ]
        )


def test_cli_references(capsys):
    assert main(["references"]) == 0
    out = capsys.readouterr().out
    assert "ruschak1976" in out
    assert "gutoff1982" in out


def test_cli_molarity_without_molar_mass_fails():
    args = [a for a in SLOT_ARGS]
    index = args.index("--molar-mass")
    del args[index : index + 2]
    with pytest.raises(SystemExit):
        main(args)


def test_cli_rejects_both_flow_and_thickness():
    with pytest.raises(SystemExit):
        main(SLOT_ARGS + ["--flow", "0.5 mL/min"])
