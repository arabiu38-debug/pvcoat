# Open items blocking publication

Everything in this repository that could be resolved from the project's own data,
sources, QA results and the author's verification has been resolved. Two values
remain that cannot be derived from anything here, and one capability that the
build environment does not have.

## 1. GitHub account name — required, not derivable

The placeholder `[name-of-github-account]` appears in:

| file | field |
|---|---|
| `CITATION.cff` | `repository-code` |
| `pyproject.toml` | `[project.urls] Homepage` |
| `pyproject.toml` | `[project.urls] Source` |
| `pyproject.toml` | `[project.urls] Issues` |

This is the account the repository will live under. It is not recorded anywhere in
the project and guessing it would put a dead URL into PyPI metadata and into a
Zenodo record, both of which are permanent. Supply it and run:

```bash
sed -i 's|\[name-of-github-account\]|YOUR-ACCOUNT|g' CITATION.cff pyproject.toml
```

Note that `pyproject.toml` is not scanned by `publish_gate.py` (the gate does not
read `.toml` files), so this substitution must be made deliberately rather than
relied on being caught.

## 2. Zenodo DOI — cannot exist yet

`CITATION.cff` carries no `doi` field. This is valid CFF and is the correct state
before deposit: a placeholder DOI is worse than no DOI. The field is added after
Step 2 of `docs/PUBLISH_GUIDE.md`, once Zenodo has minted one.

## 3. Publication could not be executed from the build environment

| requirement | status |
|---|---|
| `GITHUB_TOKEN` | not supplied |
| `ZENODO_TOKEN` / `ZENODO_SANDBOX_TOKEN` | not supplied |
| git remote configured | none |
| `api.github.com` reachable | no, blocked by the sandbox egress proxy |
| `zenodo.org` reachable | no, not on the allowed-domain list |

No push, deposit or upload was attempted or completed. Nothing has been published.
`docs/PUBLISH_GUIDE.md` carries the full procedure for doing it from a machine
that has credentials and network access.

## Not open items

For the avoidance of doubt, the following are settled and are not waiting on
anything:

- All six verification judgement calls (V1 to V6) are resolved and recorded in
  `docs/VERIFICATION_RECORD.md`.
- All watermarks, verification tags and status banners are cleared; the outputs
  in `examples/outputs/` are regenerated in released state.
- The absence of experimental validation is a documented property of v0.1.0, not
  an unresolved marker. It is stated in the README, in `docs/LIMITATIONS.md` item
  13, and in the changelog, and it is the first item of v0.2.
- The held JOSS paper is a deliberate decision, not an omission. See
  `docs/PUBLISH_GUIDE.md` Step 4.
