# Build spec — pvcoat v0.1.0

Written before any code, per `open-project-build` Step 3. If the project changes shape,
this file changes first.

```
PROJECT:   pvcoat — archetype 2 (pipeline or tool), optionally stacked with a JOSS
           software paper (archetype 2 venue) once v0.1 is released and cited.

QUESTION:  Given an ink (viscosity, surface tension, density, solids loading) and a
           coating head (gap, lip lengths, width) can I coat this film at this speed,
           and how thick will it be wet and dry?

SOURCES:   No data fetch. The inputs are published models, cited in docs/MODELS.md:
           - Landau & Levich, Acta Physicochim. URSS 17, 42 (1942)
           - Ruschak, Chem. Eng. Sci. 31, 1057 (1976)
           - Higgins & Scriven, Chem. Eng. Sci. 35, 673 (1980)
           - Gutoff & Kendrick, AIChE J. 28, 459 (1982)
           - Lee, Liu & Liu, Chem. Eng. Sci. 47, 1703 (1992)
           - Carvalho & Kheshgi, AIChE J. 46, 1907 (2000)
           - Chang et al., J. Colloid Interface Sci. 308, 222 (2007)
           - Le Berre, Chen & Baigl, Langmuir 25, 2554 (2009)
           - Ding, Liu & Schmitt, AIChE J. 62, 2508 (2016)
           - Khandavalli & Rothstein, AIChE J. 62, 4536 (2016)
           - Huang et al., Joule 8, 2313 (2024)

UNIT:      One process point = (fluid, geometry, speed, flow rate or gap).
           A window = a grid of process points.

MEASURES:  Every model is one function, SI in and SI out, each carrying its citation:
           wet_thickness            h_wet = Q / (W U)
           dry_thickness            h_dry = h_wet * phi_solids
           capillary_number         Ca = mu U / sigma
           reynolds_number          Re = rho q / mu,  q = h_wet U
           low_flow_limit           h_min = 1.34 (H_d/2) Ca^(2/3)      (LL boundary condition)
           vacuum_window            [dP_min, dP_max] from the bead pressure balance
           minimum_thickness_no_vacuum   root of dP_min(h) = 0
           air_entrainment_limit    U_ae = 6.9 mu^-0.67 (mu in mPa s, U in m/s), or Ca_crit
           landau_levich            confined: 1.34 R Ca^(2/3);  free: 0.94 l_c Ca^(2/3)
           evaporation_regime       h_dry = c E / (rho U)
           regime_crossover         U* = [E sigma^(2/3) / (1.34 R mu^(2/3))]^(3/5)

OUTPUTS:   - installable package `pvcoat` (PyPI), pure stdlib at runtime
           - CLI: `pvcoat slot-die`, `pvcoat blade`, `pvcoat window`
           - test suite (pytest), CI on 3.9-3.13
           - docs/MODELS.md (every equation, symbol, unit, source, validity range)
           - docs/LIMITATIONS.md, docs/VERIFY_CHECKLIST.md, docs/NEXT_STEPS.md
           - examples/ producing examples/outputs/stats.json, qa_report.txt, two figures
           - paper/paper.md for JOSS, held until the package has users

VENUES:    GitHub (source) -> PyPI (release) -> Zenodo (DOI, versioned).
           JOSS only if and when the package has independent users; a v0.1 with no
           users is not a JOSS submission.

VERIFY POINTS (author rules on each; see docs/VERIFY_CHECKLIST.md):
           V1  Sign convention and the upstream viscous term in the vacuum window,
               against Higgins & Scriven (1980) and Ding et al. (2016) Eqs. 8-10.
           V2  Prefactor and units of the Gutoff-Kendrick air-entrainment correlation
               (6.9, mu in mPa s, U in m/s) against the 1982 paper.
           V3  R_downstream,min = H_down/2 as the geometric minimum for a meniscus
               pinned at the downstream lip corner and tangent to the substrate.
           V4  Default Ca and Re validity ceilings (1.0 and 1.0) for the viscocapillary
               models, and the Chang et al. plateau warning threshold.
           V5  The worked perovskite example's ink properties, against your own
               rheometry and tensiometry rather than literature values.
           V6  Package name `pvcoat` and the author block spelling.

LICENSE:   Code MIT. Documentation CC BY 4.0. No data redistributed.

ASSUMPTIONS (proceeding without confirmation, flagged):
           A1  Name `pvcoat`, chosen to sit alongside `pvscribe`; free on PyPI as of
               the build date. Renaming is one command before the first push.
           A2  Newtonian ink. Non-Newtonian handling is v0.2 (docs/NEXT_STEPS.md).
           A3  Both slot-die and blade coating are in scope, per the brief; the
               degraded slot-die-only path was not needed.
           A4  Author block taken verbatim from the author's standing block;
               given/family split assumed as Abdulai / Rabiu.
```
