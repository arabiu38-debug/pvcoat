# Publish guide

Author verification is complete (`docs/VERIFICATION_RECORD.md`, 2 September 2026)
and the repository is in its release state: no watermarks, no open verification
tags, tests green, wheel built and checked. What remains is the publication
itself, which could not be executed from the environment that built the package
because no credentials were supplied and both `api.github.com` and `zenodo.org`
are unreachable from it.

Two values are still needed before anything is pushed; see `docs/OPEN_ITEMS.md`.

## Step 0 — Supply the two missing values

**Your GitHub account name.** It appears in four places and must be identical in
all of them:

- `CITATION.cff`, the `repository-code` field
- `pyproject.toml`, the `Homepage`, `Source` and `Issues` URLs

```bash
sed -i 's|\[name-of-github-account\]|YOUR-ACCOUNT|g' CITATION.cff pyproject.toml
```

**The Zenodo DOI**, which does not exist until Step 2 and is therefore added
afterwards rather than before. `CITATION.cff` currently carries no `doi` field,
which is valid CFF; add one once the DOI is minted.

Re-run the gate after the substitution:

```bash
python scripts/publish_gate.py . \
  --allow-draft-in scripts/publish_gate.py examples/_case.py examples/01_worked_case.py
```

The three allowances cover files that *implement* watermarking rather than
carrying a watermark: the gate's own pattern strings, the `draft_stamp` helper,
and the stats-file status field. They are allowances, not evasions. If anyone
regenerates the outputs without `--final`, the artifacts are stamped again and
the gate blocks again, which is the behaviour the gate exists for.

## Step 1 — GitHub

Create a fine-grained personal access token with repository-create and
contents-write permission, or a classic token with `repo` scope.

```bash
export GITHUB_TOKEN=...
python /mnt/skills/plugins/open-project-build/scripts/publish_github.py \
  --repo pvcoat \
  --description "Operability windows and film thickness for slot-die and blade coating, from published models" \
  --release v0.1.0
```

The script runs the gate itself and stops if it fails. After the push: confirm CI
is green across all five Python versions; add the topics `coating`,
`thin-films`, `slot-die`, `perovskite`, `photovoltaics`, `python`; then revoke the
token.

## Step 2 — Zenodo

The simplest route is the GitHub-Zenodo integration: sign in to Zenodo with
GitHub, enable the `pvcoat` repository, then cut the v0.1.0 release on GitHub.
Zenodo mints a DOI automatically, and will do so for every future release, with a
stable concept DOI across versions.

The scripted route, if you want control over the metadata:

```bash
export ZENODO_SANDBOX_TOKEN=...   # test on the sandbox first, always
python /mnt/skills/plugins/open-project-build/scripts/zenodo_deposit.py \
  --files pvcoat-0.1.0.zip --metadata zenodo_metadata.json --sandbox --publish
```

Metadata that matters: `upload_type: software`; `title` matching `CITATION.cff`;
`creators` as `Rabiu, Abdulai` with ORCID `0000-0002-3739-140X`; `license: mit`;
`version: 0.1.0`; `related_identifiers` pointing at the GitHub URL. Check the
sandbox record renders correctly, then repeat with `ZENODO_TOKEN` and without
`--sandbox`.

Then add the DOI to `CITATION.cff` and to the README status line, and commit.

## Step 3 — PyPI

Test on TestPyPI first; a bad release cannot be replaced, only yanked.

```bash
pip install build twine
python -m build
twine check dist/*
twine upload --repository testpypi dist/*
pip install --index-url https://test.pypi.org/simple/ pvcoat   # in a clean venv
pvcoat references
twine upload dist/*
```

Use a PyPI API token, and confirm the name `pvcoat` is still free on the day you
upload. Tag the same version on GitHub, Zenodo and PyPI so all three agree.

## Step 4 — What is deliberately not being submitted

**JOSS.** `paper/paper.md` exists and carries a hold note. JOSS requires
substantial scholarly effort and a tool with users; v0.1.0 has neither
independent users nor experimental validation, and its Statement of Need is
deliberately unwritten for that reason. Submit after the v0.2 validation work in
`docs/NEXT_STEPS.md`.

**Any journal or preprint.** There is no manuscript here and no result to report.
A tool that reproduces published equations is not a paper.

## Step 5 — Log it

The same day, record for each of GitHub, Zenodo and PyPI: the date, the artifact,
the venue, the URL or DOI, the version, and a saved PDF of the live page.
Releases that are not logged the day they happen are the ones that go missing
when you need to evidence them.

Then open the v0.2 milestone with the experimental validation work as its first
issue.
