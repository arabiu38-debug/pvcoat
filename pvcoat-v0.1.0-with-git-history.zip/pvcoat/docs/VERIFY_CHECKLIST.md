# Verification checklist

Reusable checklist for every pvcoat release. The completed record for v0.1.0 is
`docs/VERIFICATION_RECORD.md`.

Nothing in this repository is published until every line here is initialled and
dated in your own copy. `scripts/publish_gate.py` enforces the mechanical half.
The half below it cannot be scripted, which is why it is written out.

The artifact carries your name, your ORCID and your affiliation into PyPI, into a
Zenodo DOI and into anything that later cites it. An unverified coefficient in a
minted DOI is not recoverable.

## Reproduce

- [ ] Fresh clone into an empty directory; `pip install -e ".[dev]"` succeeds
- [ ] `pytest` passes on your machine, on the Python version you actually use
- [ ] `python examples/01_worked_case.py` regenerates `examples/outputs/stats.json`
      and every number in it matches the committed copy
- [ ] `python examples/02_slotdie_window.py` and `03_blade_regimes.py` regenerate
      both figures without error
- [ ] `python examples/04_render_readme.py --check` confirms the README numbers
      still match the stats file

## The six judgement calls you must personally rule on

These are the reason this file exists. Each is a place where the build made a
provisional decision that only you can confirm.

- [ ] **V1, vacuum-window pressure balance.** MODELS.md section 4. The balance
      was reconstructed from the standard viscocapillary form, not transcribed
      from Ding et al. (2016), which is paywalled. Read Higgins and Scriven (1980)
      and confirm: the sign convention on ΔP; the upstream viscous term
      `6 μ U L_u / H_u²` and its assumption of zero net upstream flow; the ±2σ/H_u
      range on the upstream meniscus. Either confirm the implementation or correct
      `_bead_pressure_terms` in `limits.py` and re-run the suite.

- [ ] **V2, Gutoff and Kendrick prefactor.** `AIR_ENTRAINMENT_PREFACTOR = 6.9`,
      `AIR_ENTRAINMENT_EXPONENT = -0.67`, μ in mPa s, U in m/s. Read Gutoff and
      Kendrick, *AIChE J.* 28, 459 (1982) and confirm both the value and the unit
      convention. Water at 6.9 m/s and 100 mPa s at 0.32 m/s are the sanity
      checks. If the units differ, every air-entrainment number in the package is
      wrong by orders of magnitude.

- [ ] **V3, R_downstream,min = H_d/2.** The geometric argument in MODELS.md
      section 2: a circle tangent to the substrate and passing through the
      downstream lip corner requires R ≥ H_d/2. Confirm the geometry, and confirm
      that Ding et al. use the same convention (some authors define the gap from
      the lip face rather than the corner).

- [ ] **V4, validity ceilings.** `CA_VISCOCAPILLARY_MAX = 1.0`,
      `RE_VISCOCAPILLARY_MAX = 1.0`, `PLATEAU_THICKNESS_RATIO = 0.44`. These are
      the build's reading of Carvalho and Kheshgi, Chang et al. and Khandavalli
      and Rothstein. Set them where your own reading of the evidence puts them.

- [ ] **V5, the worked example's ink.** `examples/_case.py` uses viscosity 3 cP,
      surface tension 30 mN/m, density 1.45 g/cm³, film density 4.1 g/cm³ and
      evaporation flux 1e-10 m²/s for a 1.4 M FAPbI₃ ink. Replace every one with
      your own rheometry, tensiometry, pycnometry and a fitted low-speed thickness
      sweep, or state in the README that they are illustrative placeholders. The
      evaporation flux in particular is a pure order-of-magnitude guess.

- [ ] **V6, name and author block.** `pvcoat` on PyPI; `AUTHORS.json` spelling,
      ORCID `0000-0002-3739-140X`, email and affiliation exactly as they should
      appear permanently. Confirm the name is still free on PyPI on the day you
      publish.

## Physics spot checks by hand

Do these with a calculator, not with pvcoat, against `examples/outputs/qa_report.txt`:

- [ ] Metering: 3.24 µm wet × 0.216 = 700 nm dry
- [ ] Ca = μU/σ at the working point
- [ ] h_min = 0.67 × 100 µm × (0.001)^(2/3)
- [ ] Vacuum window width = 4σ/H_u
- [ ] U_ae = 6.9 × 3^(−0.67)
- [ ] Blade crossover U* from the closed form, and confirm both branches meet there

## Independent cross-checks

- [ ] Compare a pvcoat low-flow limit against a published operating window figure
      (Chang et al. 2007 or Khandavalli and Rothstein 2016 are plotted as h/H vs
      Ca and can be read off directly). Record the agreement or disagreement.
- [ ] Compare a blade prediction against one of your own coated films of known
      thickness. Note the discrepancy in the README rather than hiding it.
- [ ] Confirm every DOI in `references.py` resolves.

## Before it goes public

- [ ] LIMITATIONS.md read end to end; nothing in it is a surprise to you
- [ ] Item 13 of LIMITATIONS.md (no experimental validation) is stated plainly in
      the README, and the README does not claim more than that
- [ ] README, MODELS.md and the docstrings rewritten in your own voice where they
      do not sound like you; nothing you cannot defend in a review remains
- [ ] All open verification tags resolved and removed, watermarks regenerated off
      with `--final`, placeholders replaced with the real GitHub account and DOI
- [ ] `python scripts/publish_gate.py .` passes
- [ ] Evidence log row written the day of release
