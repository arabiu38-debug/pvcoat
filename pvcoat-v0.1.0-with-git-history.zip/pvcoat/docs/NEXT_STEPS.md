# Next steps

What v0.1 deliberately leaves out, in the order it is worth adding. A released
v0.1 is a first step, not a finished thing.

## v0.2 — validation against experiment

The single most valuable addition, and the one that turns a calculator into a
citable tool.

- A `validation/` directory holding digitised operating-window data from published
  figures (Chang et al. 2007; Lin et al. 2010; Khandavalli and Rothstein 2016),
  each with its source and the digitisation method recorded.
- A script that overlays pvcoat's low-flow limit on each dataset and reports the
  agreement quantitatively, plus a figure per dataset.
- The author's own coating trials: predicted versus measured thickness across a
  speed sweep, for both heads. Even ten points would make the README honest in a
  way no amount of unit testing can.
- Once this exists, item 13 of LIMITATIONS.md can be rewritten rather than merely
  confessed.

## v0.2 — the high-Ca low-flow limit

Carvalho and Kheshgi's high inertia/capillary branch, in which the minimum wet
thickness *falls* with increasing speed, and the intermediate plateau Chang et al.
measured. Together with the implemented low-Ca branch this gives the full
three-region h_min(Ca) curve rather than one asymptote. Requires the explicit
expression from Ding et al. (2016) Eq. 12, which needs library access.

## v0.3 — non-Newtonian inks

- A `Rheology` object accepting a power-law or Carreau fit rather than a single
  viscosity, evaluated at the local gap shear rate.
- The empirical corrections for shear-thinning and shear-thickening effects on the
  minimum wet thickness reported by Khandavalli and Rothstein.
- This matters directly for concentrated perovskite precursors and for any ink
  carrying polymer additives.

## v0.3 — more failure modes

- Ribbing onset, the mode that actually terminates many lab windows.
- Breaklines and dripping.
- The upstream flooding bound properly, rather than the current thickness check.
- Each one widens what "operable" is allowed to mean, and each needs its own
  published criterion and validity range.

## v0.4 — uncertainty propagation

Accept input distributions rather than point values and report the window as a
probability rather than a boundary. A viscosity known to ±20% gives a low-flow
limit known to ±13%; a user deserves to see that rather than a false-precision
number.

## v0.4 — wetting and contact angles

Contact angles in the meniscus pinning conditions, following the free-upstream-
meniscus treatment. This is what would let pvcoat say something useful about
coating on self-assembled-monolayer-treated substrates, where the substrate
energy is the variable being engineered.

## Later

- A drying model coupling wet thickness to the final film, even a crude one.
- Multi-layer slot-die (dual-layer viscocapillary models exist and are published).
- A small web calculator built on the same functions.
- A JOSS submission, but only once the package has independent users and the
  validation of v0.2 exists. Submitting a v0.1 with no users and no validation
  would waste reviewers' time and would not survive review.

## Explicitly out of scope

- Curtain, slide, gravure and roll coating. Different heads, different limits.
- Device physics of any kind. pvcoat stops at the film.
- Optimisation or process control. It evaluates points; it does not choose them.
