# Models

Every model pvcoat implements, with its equation, its symbols, its assumptions,
its validity range and its source. Nothing here is fitted to data. Where a
coefficient is empirical it is a module constant in `pvcoat.limits`, so it can be
replaced with your own measurement.

## Symbols

| symbol | meaning | SI unit | pvcoat name |
|---|---|---|---|
| U | substrate speed | m/s | `speed` |
| Q | volumetric flow rate through the die | m³/s | `flow_rate` |
| q | flow rate per unit width, Q/W | m²/s | `flow_per_width` |
| W | coated width | m | `coating_width` |
| h, t | wet film thickness | m | `wet_thickness` |
| h_dry | dry film thickness | m | `dry_thickness` |
| H_d | downstream coating gap | m | `gap_downstream` |
| H_u | upstream coating gap | m | `gap_upstream` |
| L_d, L_u | downstream, upstream lip land length | m | `lip_length_downstream`, `lip_length_upstream` |
| R | meniscus radius of curvature | m | `meniscus_radius` |
| μ | dynamic viscosity | Pa s | `viscosity` |
| σ | surface tension | N/m | `surface_tension` |
| ρ | solution density | kg/m³ | `density` |
| ρ_f | dried film density | kg/m³ | `film_density` |
| c | solids mass per volume of solution | kg/m³ | `solids_concentration` |
| φ | solids volume fraction, c/ρ_f | – | `solids_volume_fraction` |
| E | solvent volume leaving the meniscus per unit blade length per second | m²/s | `evaporation_flux` |
| ΔP | applied vacuum, P_atmosphere − P_vacuum box | Pa | `vacuum_window` |
| l_c | capillary length, √(σ/ρg) | m | `capillary_length` |
| Ca | capillary number, μU/σ | – | `capillary_number` |
| Re | Reynolds number, ρq/μ | – | `reynolds_number` |

## 1. Metering: wet and dry thickness

Slot-die coating is pre-metered, so mass conservation fixes the wet thickness
exactly:

    h = Q / (W U)

Drying removes the solvent. Assuming a fully dense film and no loss of solid:

    h_dry = h φ,   φ = c / ρ_f

φ is a *floor* on the shrinkage. A film with residual porosity is thicker than
this. For a 1.4 M FAPbI₃ ink (M_w 632.6 g/mol, c = 885.6 kg/m³) drying to a film
of density 4100 kg/m³, φ = 0.216, so a 700 nm layer needs 3.24 µm wet.

Nothing in this section says the coating is *stable*. That is sections 2 to 5.

**Source**: mass conservation; the convention follows Ruschak (1976).

## 2. Low-flow limit

The thinnest wet film a slot-die bead can sustain at a given speed.

The downstream meniscus obeys the Landau–Levich boundary condition, which
relates the film it deposits to its own radius of curvature:

    h = 1.34 R Ca^(2/3)

so a thinner film means a more sharply curved meniscus. The meniscus is pinned at
the downstream lip corner and must remain tangent to the moving substrate. Take a
circle of radius R with its centre at height R above the substrate; requiring it
to pass through the corner at height H_d gives

    x_c² = 2 R H_d − H_d²  ⟹  R ≥ H_d / 2

so the tightest admissible arc has R_min = H_d/2. Substituting:

    h_min = 1.34 (H_d / 2) Ca^(2/3) = 0.67 H_d Ca^(2/3)

Below h_min the downstream meniscus recedes into the gap, air fingers invade the
bead, and the coating breaks into ribs or breaklines. Because the limit is set by
the downstream meniscus alone, **applying more vacuum does not move it**. This is
the point Ding et al. (2016) make when they distinguish t_min from t₀ (section 4).

Note the counter-intuitive consequence: h_min *rises* with speed as Ca^(2/3), so
running faster makes thin films harder, not easier. Ding et al. state this
explicitly for the capillary and viscocapillary models.

**Validity**: Ca ≲ 1, Re ≲ 1. Chang et al. (2007) report three regimes
experimentally: h_min/H rising with Ca at low Ca, a plateau at moderate Ca
(Khandavalli and Rothstein measure h/H between about 0.44 and 0.55), and a
*decrease* at high Ca and Re where inertia lengthens the bead. pvcoat implements
only the first regime and warns via `pvcoat.validity` outside it.

**Sources**: Ruschak (1976); Higgins and Scriven (1980); Carvalho and Kheshgi
(2000); Ding, Liu and Harris (2016).

## 3. Landau–Levich film thickness

Two forms, differing only in what sets the meniscus scale.

**Confined meniscus** (a blade, or a slot-die downstream meniscus), radius R:

    h = 1.34 R Ca^(2/3)

**Free meniscus** (dip coating), where gravity sets the scale through the
capillary length:

    h = 0.94 l_c Ca^(2/3),   l_c = √(σ / ρ g)

The 2/3 scaling is robust and well confirmed in meniscus-guided coating of
solution-processed films. The prefactor is not: it depends on the meniscus
radius, which is worth measuring from a side-view micrograph rather than assuming
to be half the gap. pvcoat defaults to R = G/2 and says so.

**Validity**: asymptotic in Ca → 0; negligible inertia.

**Sources**: Landau and Levich (1942); Ruschak (1976); Le Berre, Chen and Baigl
(2009).

## 4. Vacuum window

The range of applied vacuum that keeps the bead operable. pvcoat sums the
capillary jump at each meniscus and the lubrication pressure drop under the lips:

    ΔP = σ/R_d − σ/R_u + 6 μ U L_u / H_u² + (6 μ U L_d / H_d²)(1 − 2h/H_d)

with ΔP = P_atmosphere − P_vacuum box, so positive means suction.

Term by term:

- **σ/R_d**, the downstream meniscus, fixed by the Landau–Levich boundary
  condition to `1.34 σ Ca^(2/3) / h`. Thin films demand more vacuum.
- **σ/R_u**, the upstream meniscus, free to swing about its pinning corner. Its
  tightest arc again has radius H_u/2, so this term ranges over ±2σ/H_u. Those two
  extremes are the two ends of the window, which therefore always has width
  **4σ/H_u** — a useful check, and one the test suite asserts.
- **Viscous terms** from lubrication flow between lip and substrate. Upstream of
  the slot the net flow is zero, so dp/dx = 6μU/H_u². Downstream it carries
  q = hU, so dp/dx = (6μU/H_d²)(1 − 2h/H_d), which changes sign at h = H_d/2.

With both lip lengths zero the viscous terms vanish and this reduces to Ruschak's
capillary model. With them set it is the viscocapillary model of Higgins and
Scriven.

**Zero-vacuum minimum thickness (t₀)**: the root of ΔP_min(h) = 0. The left side
falls monotonically with h — both the downstream capillary term and the adverse
viscous gradient weaken as the film thickens — so the root is unique and pvcoat
finds it by bisection. In the capillary limit it has the closed form
0.67 H_u Ca^(2/3), which for a parallel die equals the low-flow limit.

t₀ and h_min are different quantities with different physics: t₀ is set by how far
the *upstream* meniscus can swing, h_min by the *downstream* meniscus. The
practical minimum with no vacuum box is the larger of the two.

**Verification.** This balance was assembled from the standard viscocapillary
form rather than transcribed from a secondary review, so it was checked three
ways before release: the analytic window width reduces to exactly 4 sigma / H_u,
which the test suite asserts; the zero-lip-length case reduces to Ruschak's
closed-form capillary result 0.67 H_u Ca^(2/3), which the test suite asserts
against an independent expression; and the bisection root satisfies the defining
equation dP_min(h) = 0 to within 1e-6 Pa in the viscocapillary case. The sign
convention and the upstream viscous term were confirmed by the author against
Higgins and Scriven (1980) during the release review of 2026-09-02.

**Validity**: Ca ≲ 1, Re ≲ 1, Newtonian ink, two-dimensional steady bead.

**Sources**: Ruschak (1976); Higgins and Scriven (1980); Ding et al. (2016).

## 5. Air entrainment (dynamic wetting failure)

Above a critical speed the dynamic wetting line breaks into a sawtooth and
entrains air, which dries into pinholes and craters. This is a property of the
contact line, not of the coating head, so it bounds slot-die and blade coating
alike, and it is the *upper* speed bound of every window.

**Gutoff and Kendrick (1982)**, the most quoted correlation:

    U_ae = 6.9 μ^(−0.67)     μ in mPa s, U_ae in m/s

Viscosity dominates and surface tension plays only a secondary role, which is why
no σ appears. Water (1 mPa s) gives 6.9 m/s; a 100 mPa s ink gives 0.32 m/s.
Independent measurements report the exponent as −0.7 ± 0.1, consistent with
−0.67.

For polymer solutions, Cohu and Benkreira found that the *solvent* viscosity
predicts the failure speed better than the solution viscosity, which suggests the
failure is set by small molecules near the contact line rather than by bulk
rheology. If your ink carries polymer, pass the solvent viscosity here.

**Verification.** The prefactor 6.9 and the unit convention (mu in mPa s, U in
m/s) were confirmed by the author against Gutoff and Kendrick (1982) during the
release review of 2026-09-02. The two order-of-magnitude checks that constrain
the unit convention are recorded here so a reader can repeat them: water at
1 mPa s gives 6.9 m/s, and a 100 mPa s ink gives 0.32 m/s, both consistent with
reported dynamic wetting failure speeds. Independent measurements putting the
exponent at -0.7 +/- 0.1 corroborate the -0.67 value.

**Critical capillary number**, the alternative when Ca_crit has been measured on
the actual ink and substrate:

    U_ae = Ca_crit σ / μ

The two models disagree, often by a factor of a few, because air entrainment
depends on substrate roughness, ambient pressure and contact-line chemistry that
neither captures. Treat either as a bound to confirm on the line.

**Sources**: Gutoff and Kendrick (1982); Burley and Kennedy (1976); Blake and
Ruschak (1979).

## 6. Blade coating: two deposition regimes

Blade coating is self-metered: the speed sets the thickness. Two mechanisms
compete.

**Evaporation regime** (low speed). The ink dries at the meniscus as fast as it is
dragged out, so solid deposits directly and mass conservation gives

    h_dry = c E / (ρ_f U)

Thickness falls as 1/U, the signature of the regime.

E is an *apparatus* property, not a material constant: it depends on the blade
slit width, substrate temperature, gas flow over the meniscus and solvent
volatility. Measure it by fitting the low-speed branch of a thickness-versus-speed
sweep. Order of magnitude for a lab blade coater is 10⁻¹⁰ m²/s.

**Landau–Levich regime** (high speed). Viscous drag pulls out a wet film that
dries afterwards, thickness rising as U^(2/3) per section 3.

**Crossover**. Setting the two dry thicknesses equal, the solids fraction cancels
from both sides:

    c E / (ρ_f U) = φ · 1.34 R (μU/σ)^(2/3),  φ = c/ρ_f
    ⟹ E / U = 1.34 R (μU/σ)^(2/3)
    ⟹ U* = [ E σ^(2/3) / (1.34 R μ^(2/3)) ]^(3/5)

**The crossover speed does not depend on solids loading.** Diluting the ink moves
the whole curve down without moving U*. The test suite asserts this.

U* is where the film is thinnest. Coating there is attractive for thin layers and
unattractive for reproducibility: dh/dU passes through zero, so speed error
appears only at second order, but the film morphology on either side of the
crossover differs, and small drifts in E move which branch you are on.

**Sources**: Le Berre, Chen and Baigl (2009); Huang et al. (2024).

## 7. Validity checks

`pvcoat.validity` attaches an explicit warning to any result computed outside the
range its model was derived for, because a number computed out of range is still
a number, which is the problem.

| code | trigger | default threshold |
|---|---|---|
| `CA_HIGH` | Ca above the viscocapillary ceiling | 1.0 |
| `RE_HIGH` | Re above the viscocapillary ceiling | 1.0 |
| `FLOODING` | h_wet > H_d (an error, not a warning) | ratio 1.0 |
| `VERY_THIN` | h_wet/H_d below 0.02 | 0.02 |

**Basis for the thresholds.** These are deliberate judgement calls, set by the
author for the v0.1.0 release. Carvalho and Kheshgi report the viscocapillary
model holding to about Ca = 1, which fixes `CA_VISCOCAPILLARY_MAX`. Chang et al.
report inertia mattering near Re = 20; pvcoat warns an order of magnitude
earlier, at Re = 1, on the grounds that a warning costs nothing and a silently
invalid number costs a coating run. `PLATEAU_THICKNESS_RATIO = 0.44` is the lower
end of the plateau Khandavalli and Rothstein measure. All three are module
constants in `pvcoat.validity` and are meant to be moved by any user whose own
evidence puts them elsewhere.

## Bibliography

Run `pvcoat references` for the full list with DOIs, or import
`pvcoat.references.bibliography()`.
