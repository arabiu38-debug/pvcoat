# Verification record — v0.1.0

Completed by the author, 2 September 2026, ahead of the v0.1.0 release. This file
records what was checked and what was decided. `docs/VERIFY_CHECKLIST.md` remains
as the reusable checklist for future versions.

## Reproduction

| check | result |
|---|---|
| Fresh install, `pip install -e ".[dev]"` | passes |
| `pytest` (78 checks) | passes |
| Wheel built and `twine check` | both artifacts pass |
| Clean-venv install of the wheel, CLI run from the README alone | reproduces the documented output |
| Import with no optional dependencies installed | passes; the package has no runtime dependencies |
| `examples/01_worked_case.py` regenerates `stats.json` | numbers match the committed copy |
| `examples/04_render_readme.py --check` | README numbers match the stats file |

## The six judgement calls

**V1 — vacuum-window pressure balance.** Confirmed against Higgins and Scriven
(1980). The sign convention on dP, the upstream viscous term `6 mu U L_u / H_u^2`
with its zero-net-upstream-flow assumption, and the ±2 sigma / H_u range on the
upstream meniscus are as implemented in `limits._bead_pressure_terms`. Three
independent consistency checks are recorded in `docs/MODELS.md` section 4 and are
asserted by the test suite. **Accepted as implemented.**

**V2 — Gutoff and Kendrick prefactor and units.** Confirmed against Gutoff and
Kendrick, *AIChE J.* 28, 459 (1982). `AIR_ENTRAINMENT_PREFACTOR = 6.9`,
`AIR_ENTRAINMENT_EXPONENT = -0.67`, mu in mPa s, U in m/s. The order-of-magnitude
checks (water 6.9 m/s; 100 mPa s ink 0.32 m/s) are consistent with the reported
correlation. **Accepted as implemented.**

**V3 — R_downstream,min = H_d / 2.** The geometric argument in `docs/MODELS.md`
section 2 was re-derived and confirmed: a circle tangent to the substrate passing
through the downstream lip corner requires x_c^2 = 2 R H_d − H_d^2, hence
R >= H_d / 2. The gap convention (measured from the lip corner) matches the
source. **Accepted as implemented.**

**V4 — validity ceilings.** `CA_VISCOCAPILLARY_MAX = 1.0`,
`RE_VISCOCAPILLARY_MAX = 1.0`, `PLATEAU_THICKNESS_RATIO = 0.44`. Basis recorded in
`docs/MODELS.md` section 7. The Re ceiling is deliberately an order of magnitude
below the Re ≈ 20 transition Chang et al. report, because a warning is cheap and a
silently invalid number is not. **Accepted as set.**

**V5 — worked-example ink properties.** Resolved by the second of the two options
the checklist allowed: the ink properties in `examples/_case.py` are retained as
illustrative values and are labelled as illustrative placeholders, not
measurements, in the README worked-example block, in `examples/_case.py` itself,
and in the figure captions. The evaporation flux E in particular remains an
order-of-magnitude value; `docs/LIMITATIONS.md` item 8 states that it is an
apparatus constant that must be measured on the user's own coater. No claim is
made anywhere that these are measured values. **Resolved by labelling.**

**V6 — name and author block.** Package name `pvcoat` confirmed by the author and
free on PyPI as of the build date. Author block in `AUTHORS.json` confirmed:
Abdulai Rabiu, ORCID 0000-0002-3739-140X, arabiu@rockets.utoledo.edu, Wright
Center for Photovoltaics Innovation and Commercialization, Department of Physics
and Astronomy, University of Toledo. **Accepted.**

## Physics spot checks by hand

Recomputed independently of pvcoat and checked against
`examples/outputs/qa_report.txt`:

| check | expected | reported |
|---|---|---|
| 3.2406 um x 0.21601 | 700 nm | 700.0 nm |
| Ca = 0.003 x 0.01 / 0.03 | 1.000e-3 | 1.000e-3 |
| h_min = 0.67 x 100 um x (1e-3)^(2/3) | 0.670 um | 0.6700 um |
| vacuum window width = 4 x 0.03 / 100e-6 | 12.00 mbar | 12.000 mbar |
| U_ae = 6.9 x 3^(-0.67) | 3.305 m/s | 3.305 m/s |
| blade branches equal at U* | equal | equal to 1 part in 1e9 |

## What was deliberately not resolved, and why

**No experimental validation.** pvcoat v0.1.0 has not been tested against a
coating trial. This is stated in the README and as item 13 of
`docs/LIMITATIONS.md`, and closing it is the first item in `docs/NEXT_STEPS.md`.
The release is made on the understanding that pvcoat is a calculator for
published models and is described as nothing more than that.

**The JOSS paper is held.** `paper/paper.md` is not submitted and its Statement of
Need is deliberately unwritten, because the section cannot be written honestly
until the package has independent users. This is a substantive hold, not an
oversight.

Signed: Abdulai Rabiu, 2 September 2026.
